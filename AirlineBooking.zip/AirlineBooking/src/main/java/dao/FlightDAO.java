package dao;

import model.Flight;
import util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightDAO {
    public List<Flight> getAllFlights() throws SQLException {
        List<Flight> flights = new ArrayList<>();
        String sql = "SELECT * FROM CHUYENBAY";

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Flight flight = new Flight(
                        rs.getString("MaChuyenBay"),
                        rs.getTimestamp("NgayGio").toLocalDateTime(),
                        rs.getInt("ThoiGianBay"),
                        rs.getInt("SoLuongGheHang1"),
                        rs.getInt("SoLuongGheHang2"),
                        rs.getString("MaChiTietChuyenBay"),
                        rs.getString("MaTuyenBay"),
                        rs.getString("MaMayBay")
                );
                flights.add(flight);
            }
        }
        return flights;
    }

    public Flight getFlightById(String flightId) throws SQLException {
        String sql = "SELECT * FROM CHUYENBAY WHERE MaChuyenBay = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, flightId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Flight(
                            rs.getString("MaChuyenBay"),
                            rs.getTimestamp("NgayGio").toLocalDateTime(),
                            rs.getInt("ThoiGianBay"),
                            rs.getInt("SoLuongGheHang1"),
                            rs.getInt("SoLuongGheHang2"),
                            rs.getString("MaChiTietChuyenBay"),
                            rs.getString("MaTuyenBay"),
                            rs.getString("MaMayBay")
                    );
                }
            }
        }
        return null;
    }
    
}
