package controller;

import service.FlightService;
import model.Flight;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/searchFlights")
public class FlightSearchServlet extends HttpServlet {
    private final FlightService flightService = new FlightService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String departure = request.getParameter("departure");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");

        List<Flight> flights = flightService.searchFlights(departure, destination, date);
        request.setAttribute("flights", flights);

        request.getRequestDispatcher("/views/flightResults.jsp").forward(request, response);
    }
}
