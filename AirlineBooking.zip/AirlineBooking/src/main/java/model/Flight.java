package model;

import java.time.LocalDateTime;

public class Flight {
    private String id;
    private LocalDateTime dateTime;
    private int duration;
    private int seatsClass1;
    private int seatsClass2;
    private String detailId;
    private String routeId;
    private String planeId;

    public Flight(String id, LocalDateTime dateTime, int duration, int seatsClass1, int seatsClass2, String detailId, String routeId, String planeId) {
        this.id = id;
        this.dateTime = dateTime;
        this.duration = duration;
        this.seatsClass1 = seatsClass1;
        this.seatsClass2 = seatsClass2;
        this.detailId = detailId;
        this.routeId = routeId;
        this.planeId = planeId;
    }

    // Getters and setters
}
