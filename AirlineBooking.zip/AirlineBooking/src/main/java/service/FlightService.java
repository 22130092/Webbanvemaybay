package service;

import dao.FlightDAO;
import model.Flight;

import java.util.List;

public class FlightService {
    private final FlightDAO flightDAO = new FlightDAO();

    public List<Flight> searchFlights(String departure, String destination, String date) {
        return flightDAO.getFlights(departure, destination, date);
    }
}
