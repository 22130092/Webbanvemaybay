// Banner animation
window.addEventListener('load', () => {
    const bannerText = document.querySelector('.banner-text');
    bannerText.classList.add('fade-in');
});

// Smooth scroll for navigation links
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
