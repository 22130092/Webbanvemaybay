package dao;

import controller.ConnectDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.ChuyenBay;
import model.VeMayBay;

public class ChuyenBayDAO implements DAOInterface<ChuyenBay> {
	public static ChuyenBayDAO getInstance() {
		return new ChuyenBayDAO();
	}

	@Override
	public int insert(ChuyenBay t) {
		int kq = 0;
		try {
			// B1: tao ket noi den CSDl
			Connection con = ConnectDB.getConnection();

			// B2: tao ra doi tuong statement
			Statement st = con.createStatement();

			// B3: thuc thi cau lenh SQL
			String sql = "INSERT INTO `chuyenbay` (`MaChuyenBay`, `NgayGio`, `ThoiGianBay`, `SoLuongGheHang1`, `SoLuongGheHang2`, `MaChiTietChuyenBay`, `MaTuyenBay`, `MaMayBay`) "
					+ "VALUES ('" + t.getMaChuyenBay() + "','" + t.getNgayGio() + "'," + t.getThoiGianBay() + ","
					+ t.getSoLuongGheHang1() + "," + t.getSoLuongGheHang2() + ",'" + t.getMaChiTietChuyenBay() + "','"
					+ t.getMaTuyenBay() + "','" + t.getMaMayBay() + "')";

			// B4: xu ly kq tra ve
			System.out.println("Ban da thuc thi : " + sql);

			kq += st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Update " + kq + " dong thanh cong");
			} else {
				System.out.println("Update that bay");
			}
			// B5: dong ket noi
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int delete(ChuyenBay t) {
		int kq = 0;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "DELETE FROM `chuyenbay` " + "WHERE MaChuyenBay = '" + t.getMaChuyenBay() + "'";

			// B4: Xử lý kết quả trả về
			System.out.println("Bạn đã thực thi: " + sql);

			kq = st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Xóa " + kq + " dòng thành công");
			} else {
				System.out.println("Không tìm thấy bản ghi cần xóa");
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int update(ChuyenBay t) {
		int kq = 0;
		try {
			// B1: tao ket noi den CSDl
			Connection con = ConnectDB.getConnection();

			// B2: tao ra doi tuong statement
			Statement st = con.createStatement();

			// B3: thuc thi cau lenh SQL
			String sql = "UPDATE `chuyenbay` " + "SET NgayGio = '" + t.getNgayGio() + "', " + "ThoiGianBay = "
					+ t.getThoiGianBay() + ", " + "SoLuongGheHang1 = " + t.getSoLuongGheHang1() + ", "
					+ "SoLuongGheHang2 = " + t.getSoLuongGheHang2() + ", " + "MaChiTietChuyenBay = '"
					+ t.getMaChiTietChuyenBay() + "', " + "MaTuyenBay = '" + t.getMaTuyenBay() + "', " + "MaMayBay = '"
					+ t.getMaMayBay() + "' " + "WHERE MaChuyenBay = '" + t.getMaChuyenBay() + "'";

			// B4: xu ly kq tra ve
			System.out.println("Ban da thuc thi : " + sql);

			kq += st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Update " + kq + " dong thanh cong");
			} else {
				System.out.println("Update that bay");
			}
			// B5: dong ket noi
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public ArrayList<ChuyenBay> selectAll() {
		ArrayList<ChuyenBay> ketQua = new ArrayList<ChuyenBay>();
		try {
			// B1: tao ket noi den CSDl
			Connection con = ConnectDB.getConnection();

			// B2: tao ra doi tuong statement
			Statement st = con.createStatement();

			// B3: thuc thi cau lenh SQL
			String sql = "SELECT * FROM `chuyenbay`";

			// B4: xu ly kq tra ve
			System.out.println("Ban da thuc thi : " + sql);
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				 String maChuyenBay=rs.getString("maChuyenBay");
			     String ngayGio=rs.getString("ngayGio");
			     int thoiGianBay=rs.getInt("thoiGianBay");
			     int soLuongGheHang1=rs.getInt("soLuongGheHang1");
			     int soLuongGheHang2=rs.getInt("soLuongGheHang2");
			     String maChiTietChuyenBay=rs.getString("maChiTietChuyenBay");
			     String maTuyenBay=rs.getString("maTuyenBay");
			     String maMayBay=rs.getString("maMayBay");
			     ChuyenBay cb = new ChuyenBay(maChuyenBay, ngayGio, thoiGianBay, soLuongGheHang1, soLuongGheHang2, maChiTietChuyenBay, maTuyenBay, maMayBay);
			     ketQua.add(cb);
			}
			// B5: dong ket noi
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketQua;
	}

	@Override
	public ChuyenBay selectById(ChuyenBay t) {
		ChuyenBay ketqua=null;
		try {
			// B1: tao ket noi den CSDl
			Connection con = ConnectDB.getConnection();

			// B2: tao ra doi tuong statement
			Statement st = con.createStatement();

			// B3: thuc thi cau lenh SQL
			String sql = "SELECT * FROM `chuyenbay` Where `machuyenbay` = '"+t.getMaChuyenBay()+"'";

			// B4: xu ly kq tra ve
			System.out.println("Ban da thuc thi : " + sql);
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				 String maChuyenBay=rs.getString("maChuyenBay");
			     String ngayGio=rs.getString("ngayGio");
			     int thoiGianBay=rs.getInt("thoiGianBay");
			     int soLuongGheHang1=rs.getInt("soLuongGheHang1");
			     int soLuongGheHang2=rs.getInt("soLuongGheHang2");
			     String maChiTietChuyenBay=rs.getString("maChiTietChuyenBay");
			     String maTuyenBay=rs.getString("maTuyenBay");
			     String maMayBay=rs.getString("maMayBay");
			     ketqua = new ChuyenBay(maChuyenBay, ngayGio, thoiGianBay, soLuongGheHang1, soLuongGheHang2, maChiTietChuyenBay, maTuyenBay, maMayBay);
			    
			}
			// B5: dong ket noi
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketqua;
	}

	@Override
	public ArrayList<ChuyenBay> selectByCondition(String condition) {
		ArrayList<ChuyenBay> ketQua = new ArrayList<ChuyenBay>();
		try {
			// B1: tao ket noi den CSDl
			Connection con = ConnectDB.getConnection();

			// B2: tao ra doi tuong statement
			Statement st = con.createStatement();

			// B3: thuc thi cau lenh SQL
			String sql = "SELECT * FROM `chuyenbay` where "+condition;

			// B4: xu ly kq tra ve
			System.out.println("Ban da thuc thi : " + sql);
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				 String maChuyenBay=rs.getString("maChuyenBay");
			     String ngayGio=rs.getString("ngayGio");
			     int thoiGianBay=rs.getInt("thoiGianBay");
			     int soLuongGheHang1=rs.getInt("soLuongGheHang1");
			     int soLuongGheHang2=rs.getInt("soLuongGheHang2");
			     String maChiTietChuyenBay=rs.getString("maChiTietChuyenBay");
			     String maTuyenBay=rs.getString("maTuyenBay");
			     String maMayBay=rs.getString("maMayBay");
			     ChuyenBay cb = new ChuyenBay(maChuyenBay, ngayGio, thoiGianBay, soLuongGheHang1, soLuongGheHang2, maChiTietChuyenBay, maTuyenBay, maMayBay);
			     ketQua.add(cb);
			}
			// B5: dong ket noi
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketQua;
	}

}
