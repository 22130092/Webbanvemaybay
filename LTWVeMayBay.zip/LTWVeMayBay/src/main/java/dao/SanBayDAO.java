package dao;

import controller.ConnectDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.SanBay;

public class SanBayDAO implements DAOInterface<SanBay> {
    public static SanBayDAO getInstance() {
        return new SanBayDAO();
    }

    @Override
    public int insert(SanBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "INSERT INTO `sanbay` (`MaSanBay`, `TenSanBay`) VALUES ('"
                    + t.getMaSanBay() + "', '" + t.getTenSanBay() + "')";

            // B4: Xử lý kết quả trả về
            kq += st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int delete(SanBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "DELETE FROM `sanbay` WHERE `MaSanBay` = '" + t.getMaSanBay() + "'";

            // B4: Xử lý kết quả trả về
            kq = st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int update(SanBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "UPDATE `sanbay` SET `TenSanBay` = '" + t.getTenSanBay() + "' WHERE `MaSanBay` = '" + t.getMaSanBay() + "'";

            // B4: Xử lý kết quả trả về
            kq = st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public ArrayList<SanBay> selectAll() {
        ArrayList<SanBay> ketQua = new ArrayList<SanBay>();
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `sanbay`";

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String maSanBay = rs.getString("MaSanBay");
                String tenSanBay = rs.getString("TenSanBay");
                SanBay sanBay = new SanBay(maSanBay, tenSanBay);
                ketQua.add(sanBay);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public SanBay selectById(SanBay t) {
        SanBay ketQua = null;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `sanbay` WHERE `MaSanBay` = '" + t.getMaSanBay() + "'";

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                String maSanBay = rs.getString("MaSanBay");
                String tenSanBay = rs.getString("TenSanBay");
                ketQua = new SanBay(maSanBay, tenSanBay);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public ArrayList<SanBay> selectByCondition(String condition) {
        ArrayList<SanBay> ketQua = new ArrayList<SanBay>();
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `sanbay` WHERE " + condition;

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String maSanBay = rs.getString("MaSanBay");
                String tenSanBay = rs.getString("TenSanBay");
                SanBay sanBay = new SanBay(maSanBay, tenSanBay);
                ketQua.add(sanBay);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }
}
