package dao;

import controller.ConnectDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.TuyenBay;

public class TuyenBayDAO implements DAOInterface<TuyenBay> {
    public static TuyenBayDAO getInstance() {
        return new TuyenBayDAO();
    }

    @Override
    public int insert(TuyenBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "INSERT INTO `tuyenbay` (`MaTuyenBay`, `MaSanBayDi`, `MaSanBayDen`) VALUES ('"
                    + t.getMaTuyenBay() + "', '" + t.getMaSanBayDi() + "', '" + t.getMaSanBayDen() + "')";

            // B4: Xử lý kết quả trả về
            kq += st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int delete(TuyenBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "DELETE FROM `tuyenbay` WHERE `MaTuyenBay` = '" + t.getMaTuyenBay() + "'";

            // B4: Xử lý kết quả trả về
            kq = st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int update(TuyenBay t) {
        int kq = 0;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "UPDATE `tuyenbay` SET `MaSanBayDi` = '" + t.getMaSanBayDi() + "', `MaSanBayDen` = '" + t.getMaSanBayDen() + "' WHERE `MaTuyenBay` = '" + t.getMaTuyenBay() + "'";

            // B4: Xử lý kết quả trả về
            kq = st.executeUpdate(sql);

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public ArrayList<TuyenBay> selectAll() {
        ArrayList<TuyenBay> ketQua = new ArrayList<TuyenBay>();
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `tuyenbay`";

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String maTuyenBay = rs.getString("MaTuyenBay");
                String maSanBayDi = rs.getString("MaSanBayDi");
                String maSanBayDen = rs.getString("MaSanBayDen");
                TuyenBay tuyenBay = new TuyenBay(maTuyenBay, maSanBayDi, maSanBayDen);
                ketQua.add(tuyenBay);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public TuyenBay selectById(TuyenBay t) {
        TuyenBay ketQua = null;
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `tuyenbay` WHERE `MaTuyenBay` = '" + t.getMaTuyenBay() + "'";

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                String maTuyenBay = rs.getString("MaTuyenBay");
                String maSanBayDi = rs.getString("MaSanBayDi");
                String maSanBayDen = rs.getString("MaSanBayDen");
                ketQua = new TuyenBay(maTuyenBay, maSanBayDi, maSanBayDen);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public ArrayList<TuyenBay> selectByCondition(String condition) {
        ArrayList<TuyenBay> ketQua = new ArrayList<TuyenBay>();
        try {
            // B1: Tạo kết nối đến CSDL
            Connection con = ConnectDB.getConnection();

            // B2: Tạo đối tượng statement
            Statement st = con.createStatement();

            // B3: Thực thi câu lệnh SQL
            String sql = "SELECT * FROM `tuyenbay` WHERE " + condition;

            // B4: Xử lý kết quả trả về
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String maTuyenBay = rs.getString("MaTuyenBay");
                String maSanBayDi = rs.getString("MaSanBayDi");
                String maSanBayDen = rs.getString("MaSanBayDen");
                TuyenBay tuyenBay = new TuyenBay(maTuyenBay, maSanBayDi, maSanBayDen);
                ketQua.add(tuyenBay);
            }

            // B5: Đóng kết nối
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ketQua;
    }
}
