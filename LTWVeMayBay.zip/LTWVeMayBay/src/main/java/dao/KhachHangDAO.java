package dao;

import controller.ConnectDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.KhachHang;

public class KhachHangDAO implements DAOInterface<KhachHang> {
	public static KhachHangDAO getInstance() {
		return new KhachHangDAO();
	}

	@Override
	public int insert(KhachHang t) {
		int kq = 0;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "INSERT INTO `khachhang` (`TenKhachHang`, `CMND`, `DienThoai`) " + "VALUES ('"
					+ t.getTenKhachHang() + "','" + t.getSoCMND() + "','" + t.getSoDienThoai() + "')";

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);

			kq += st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Insert " + kq + " dong thanh cong");
			} else {
				System.out.println("Insert that bai");
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int delete(KhachHang t) {
		int kq = 0;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "DELETE FROM `khachhang` WHERE `CMND` = '" + t.getSoCMND() + "'";

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);

			kq = st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Xoa " + kq + " dong thanh cong");
			} else {
				System.out.println("Khong tim thay ban ghi can xoa");
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int update(KhachHang t) {
		int kq = 0;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "UPDATE `khachhang` " + "SET `TenKhachHang` = '" + t.getTenKhachHang() + "', "
					+ "`DienThoai` = '" + t.getSoDienThoai() + "' " + "WHERE `CMND` = '" + t.getSoCMND() + "'";

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);

			kq += st.executeUpdate(sql);
			if (kq > 0) {
				System.out.println("Update " + kq + " dong thanh cong");
			} else {
				System.out.println("Update that bai");
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public ArrayList<KhachHang> selectAll() {
		ArrayList<KhachHang> ketQua = new ArrayList<KhachHang>();
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "SELECT * FROM `khachhang`";

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				String tenKhachHang = rs.getString("TenKhachHang");
				String soCMND = rs.getString("CMND");
				String soDienThoai = rs.getString("DienThoai");
				KhachHang kh = new KhachHang(tenKhachHang, soCMND, soDienThoai);
				ketQua.add(kh);
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketQua;
	}

	@Override
	public KhachHang selectById(KhachHang t) {
		KhachHang ketQua = null;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "SELECT * FROM `khachhang` WHERE `DienThoai` = '" + t.getSoDienThoai() + "'";

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);
			ResultSet rs = st.executeQuery(sql);

			if (rs.next()) {
				String tenKhachHang = rs.getString("KhachHang");
				String soCMND = rs.getString("CMND");
				String soDienThoai = rs.getString("DienThoai");
				ketQua = new KhachHang(tenKhachHang, soCMND, soDienThoai);
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketQua;
	}

	@Override
	public ArrayList<KhachHang> selectByCondition(String condition) {
		ArrayList<KhachHang> ketQua = new ArrayList<KhachHang>();
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();

			// B2: Tạo đối tượng statement
			Statement st = con.createStatement();

			// B3: Thực thi câu lệnh SQL
			String sql = "SELECT * FROM `khachhang` WHERE " + condition;

			// B4: Xử lý kết quả trả về
			System.out.println("Ban da thuc thi: " + sql);
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				String tenKhachHang = rs.getString("TenKhachHang");
				String soCMND = rs.getString("CMND");
				String soDienThoai = rs.getString("DienThoai");
				KhachHang kh = new KhachHang(tenKhachHang, soCMND, soDienThoai);
				ketQua.add(kh);
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ketQua;
	}
}
