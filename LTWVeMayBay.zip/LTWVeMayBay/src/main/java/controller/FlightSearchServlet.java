package controller;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/searchFlights")
public class FlightSearchServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String from = request.getParameter("from");
        String to = request.getParameter("to");
        String departureDate = request.getParameter("departure");

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/flight_booking", "root", "")) {
            String sql = "SELECT * FROM flights WHERE departure = ? AND destination = ? AND departure_date = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, from);
                ps.setString(2, to);
                ps.setString(3, departureDate);

                ResultSet rs = ps.executeQuery();
                request.setAttribute("flightResults", rs);
                request.getRequestDispatcher("flightResults.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage());
        }
    }
}
