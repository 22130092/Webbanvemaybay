package controller;

import java.util.ArrayList;

import dao.ChuyenBayDAO;
import model.ChuyenBay;

public class TestConnect {
	public static void main(String[] args) {
//		ChuyenBay c1 = new ChuyenBay("CB15", "2024-12-15 06:36:47.000000", 200, 60, 150,null, "TB10", "MB10");
//		ChuyenBayDAO.getInstance().insert(c1);
//		for (int i = 0; i < 100; i++) {
//			ChuyenBay c = new ChuyenBay("CB15"+i, "2024-12-15 06:36:47.000000", 200, 60, 150,null, "TB10", "MB10");
//			ChuyenBayDAO.getInstance().delete(c);
//		}
//		ChuyenBay c1 = new ChuyenBay("CB15", "2024-12-15 06:36:47.000000", 200, 60, 150,"CTCB01", "TB10", "MB10");
//		ChuyenBayDAO.getInstance().insert(c1);
		
		ArrayList<ChuyenBay> list = ChuyenBayDAO.getInstance().selectAll();
		for (ChuyenBay chuyenBay : list) {
			System.out.println(chuyenBay.toString());
		}
		ChuyenBay c1 = new ChuyenBay("CB15", "2024-12-15 06:36:47.000000", 200, 60, 150, "CTCB01", "TB10", "MB10");
		ChuyenBay cb = ChuyenBayDAO.getInstance().selectById(c1);
		System.out.println(cb);
		
		ArrayList<ChuyenBay> list2 = ChuyenBayDAO.getInstance().selectByCondition("thoigianbay>100");
		for (ChuyenBay chuyenBay : list2) {
			System.out.println(chuyenBay.toString());
		}
		
	}

}
