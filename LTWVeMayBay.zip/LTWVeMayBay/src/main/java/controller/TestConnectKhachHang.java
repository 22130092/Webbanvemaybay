package controller;

import java.util.ArrayList;

import dao.KhachHangDAO;
import model.KhachHang;

public class TestConnectKhachHang {
    public static void main(String[] args) {
        // Test insert
        KhachHang kh1 = new KhachHang("Nguyen Van A", "12345679", "0987654321");
        //KhachHangDAO.getInstance().insert(kh1);

        // Test selectAll
//        ArrayList<KhachHang> list = KhachHangDAO.getInstance().selectAll();
//        for (KhachHang khachHang : list) {
//            System.out.println(khachHang.toString());
//        }

        // Test selectById
        KhachHang kh2 = new KhachHang("Trần Thị B", "987654321", "0912345678");
        KhachHang khachHangById = KhachHangDAO.getInstance().selectById(kh2);
        System.out.println("Selected by ID: " + khachHangById);

        // Test selectByCondition
        ArrayList<KhachHang> list2 = KhachHangDAO.getInstance().selectByCondition("DienThoai='0987654321'");
        for (KhachHang khachHang : list2) {
            System.out.println("Selected by condition: " + khachHang.toString());
        }

    }
}
