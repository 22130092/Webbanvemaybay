package model;

public class MayBay {
    private String maMayBay;
    private String loaiMayBay;

    public MayBay(String maMayBay, String loaiMayBay) {
        this.maMayBay = maMayBay;
        this.loaiMayBay = loaiMayBay;
    }

    public String getMaMayBay() {
        return maMayBay;
    }

    public void setMaMayBay(String maMayBay) {
        this.maMayBay = maMayBay;
    }

    public String getLoaiMayBay() {
        return loaiMayBay;
    }

    public void setLoaiMayBay(String loaiMayBay) {
        this.loaiMayBay = loaiMayBay;
    }
}
