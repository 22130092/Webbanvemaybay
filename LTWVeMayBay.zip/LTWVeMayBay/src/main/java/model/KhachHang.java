package model;

public class KhachHang {

	private String tenKhachHang;
	private String soCMND;
	private String soDienThoai;

	public KhachHang(String tenKhachHang, String soCMND, String soDienThoai) {

		this.tenKhachHang = tenKhachHang;
		this.soCMND = soCMND;
		this.soDienThoai = soDienThoai;
	}

	public String getTenKhachHang() {
		return tenKhachHang;
	}

	public void setTenKhachHang(String tenKhachHang) {
		this.tenKhachHang = tenKhachHang;
	}

	public String getSoCMND() {
		return soCMND;
	}

	public void setSoCMND(String soCMND) {
		this.soCMND = soCMND;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	@Override
	public String toString() {
		return "KhachHang [tenKhachHang=" + tenKhachHang + ", soCMND=" + soCMND + ", soDienThoai=" + soDienThoai + "]";
	}

}
