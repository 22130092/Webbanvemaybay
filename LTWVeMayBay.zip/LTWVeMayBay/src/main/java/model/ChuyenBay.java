package model;

public class ChuyenBay {
    private String maChuyenBay;
    private String ngayGio;
    private int thoiGianBay;
    private int soLuongGheHang1;
    private int soLuongGheHang2;
    private String maChiTietChuyenBay;
    private String maTuyenBay;
    private String maMayBay;

    public ChuyenBay(String maChuyenBay, String ngayGio, int thoiGianBay, int soLuongGheHang1, int soLuongGheHang2,String maChiTietChuyenBay, String maTuyenBay, String maMayBay) {
        this.maChuyenBay = maChuyenBay;
        this.ngayGio = ngayGio;
        this.thoiGianBay = thoiGianBay;
        this.soLuongGheHang1 = soLuongGheHang1;
        this.soLuongGheHang2 = soLuongGheHang2;
        this.maChiTietChuyenBay=maChiTietChuyenBay;
        this.maTuyenBay = maTuyenBay;
        this.maMayBay = maMayBay;
    }

    public String getMaChuyenBay() {
        return maChuyenBay;
    }

    public void setMaChuyenBay(String maChuyenBay) {
        this.maChuyenBay = maChuyenBay;
    }

    public String getNgayGio() {
        return ngayGio;
    }

    public void setNgayGio(String ngayGio) {
        this.ngayGio = ngayGio;
    }

    public int getThoiGianBay() {
        return thoiGianBay;
    }

    public void setThoiGianBay(int thoiGianBay) {
        this.thoiGianBay = thoiGianBay;
    }

    public int getSoLuongGheHang1() {
        return soLuongGheHang1;
    }

    public void setSoLuongGheHang1(int soLuongGheHang1) {
        this.soLuongGheHang1 = soLuongGheHang1;
    }

    public int getSoLuongGheHang2() {
        return soLuongGheHang2;
    }

    public void setSoLuongGheHang2(int soLuongGheHang2) {
        this.soLuongGheHang2 = soLuongGheHang2;
    }

    public String getMaTuyenBay() {
        return maTuyenBay;
    }

    public void setMaTuyenBay(String maTuyenBay) {
        this.maTuyenBay = maTuyenBay;
    }

    public String getMaMayBay() {
        return maMayBay;
    }

    public void setMaMayBay(String maMayBay) {
        this.maMayBay = maMayBay;
    }

	public String getMaChiTietChuyenBay() {
		return maChiTietChuyenBay;
	}

	public void setMaChiTietChuyenBay(String maChiTietChuyenBay) {
		this.maChiTietChuyenBay = maChiTietChuyenBay;
	}

	@Override
	public String toString() {
		return "ChuyenBay [maChuyenBay=" + maChuyenBay + ", ngayGio=" + ngayGio + ", thoiGianBay=" + thoiGianBay
				+ ", soLuongGheHang1=" + soLuongGheHang1 + ", soLuongGheHang2=" + soLuongGheHang2
				+ ", maChiTietChuyenBay=" + maChiTietChuyenBay + ", maTuyenBay=" + maTuyenBay + ", maMayBay=" + maMayBay
				+ "]";
	}
    
}
