package model;

public class HangVe {
    private String maHangVe;
    private String tenHangVe;

    public HangVe(String maHangVe, String tenHangVe) {
        this.maHangVe = maHangVe;
        this.tenHangVe = tenHangVe;
    }

    public String getMaHangVe() {
        return maHangVe;
    }

    public void setMaHangVe(String maHangVe) {
        this.maHangVe = maHangVe;
    }

    public String getTenHangVe() {
        return tenHangVe;
    }

    public void setTenHangVe(String tenHangVe) {
        this.tenHangVe = tenHangVe;
    }
}
