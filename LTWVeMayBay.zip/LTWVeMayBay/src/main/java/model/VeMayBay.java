package model;

public class VeMayBay {
    private String maVe;
    private String maChuyenBay;
    private String maKhachHang;
    private String loaiGhe;

    public VeMayBay(String maVe, String maChuyenBay, String maKhachHang, String loaiGhe) {
        this.maVe = maVe;
        this.maChuyenBay = maChuyenBay;
        this.maKhachHang = maKhachHang;
        this.loaiGhe = loaiGhe;
    }

    public String getMaVe() {
        return maVe;
    }

    public void setMaVe(String maVe) {
        this.maVe = maVe;
    }

    public String getMaChuyenBay() {
        return maChuyenBay;
    }

    public void setMaChuyenBay(String maChuyenBay) {
        this.maChuyenBay = maChuyenBay;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getLoaiGhe() {
        return loaiGhe;
    }

    public void setLoaiGhe(String loaiGhe) {
        this.loaiGhe = loaiGhe;
    }
}
