package model;
public class SanBay {
    private String maSanBay;
    private String tenSanBay;

    public SanBay(String maSanBay, String tenSanBay) {
        this.maSanBay = maSanBay;
        this.tenSanBay = tenSanBay;
    }

    public String getMaSanBay() {
        return maSanBay;
    }

    public void setMaSanBay(String maSanBay) {
        this.maSanBay = maSanBay;
    }

    public String getTenSanBay() {
        return tenSanBay;
    }

    public void setTenSanBay(String tenSanBay) {
        this.tenSanBay = tenSanBay;
    }
}