package model;

public class DonGia {
    private String maDonGia;
    private double giaTien;

    public DonGia(String maDonGia, double giaTien) {
        this.maDonGia = maDonGia;
        this.giaTien = giaTien;
    }

    public String getMaDonGia() {
        return maDonGia;
    }

    public void setMaDonGia(String maDonGia) {
        this.maDonGia = maDonGia;
    }

    public double getGiaTien() {
        return giaTien;
    }

    public void setGiaTien(double giaTien) {
        this.giaTien = giaTien;
    }
}
