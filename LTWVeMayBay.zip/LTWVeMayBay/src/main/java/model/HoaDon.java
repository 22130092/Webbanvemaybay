package model;

public class HoaDon {
    private String maHoaDon;
    private String maVe;
    private double giaTien;

    public HoaDon(String maHoaDon, String maVe, double giaTien) {
        this.maHoaDon = maHoaDon;
        this.maVe = maVe;
        this.giaTien = giaTien;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getMaVe() {
        return maVe;
    }

    public void setMaVe(String maVe) {
        this.maVe = maVe;
    }

    public double getGiaTien() {
        return giaTien;
    }

    public void setGiaTien(double giaTien) {
        this.giaTien = giaTien;
    }
}
