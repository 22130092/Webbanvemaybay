	<%@ include file="header.jsp"%>
	<%@ page language="java" contentType="text/html; charset=UTF-8"
		pageEncoding="UTF-8"%>
	<!doctype html>
	<html lang="en">
	<head>
	<%
    session = request.getSession();
    User user = (User) session.getAttribute("user");
    if (user != null) {
        response.sendRedirect("index.jsp"); // Redirect to login if not logged in
        return;
    }
%>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport"
		content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link
		href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap"
		rel="stylesheet">
	
	<link rel="stylesheet" href="css/style.css">
	
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/main.js"></script>
	
	
	
	<link rel="stylesheet"
		href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<section class="ftco-section">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-7 col-lg-5">
						<div class="wrap">
							<div class="img" style="background-image: url('images/bg-1.jpg');"></div>
	
							<div class="login-wrap p-4 p-md-5">
								<div class="d-flex">
									<div class="w-100">
										<h3 class="mb-4">Sign In</h3>
									</div>
									<div class="w-100">
										<p class="social-media d-flex justify-content-end">
											<a href="#"
												class="social-icon d-flex align-items-center justify-content-center"><span
												class="fa fa-facebook"></span></a> <a href="#"
												class="social-icon d-flex align-items-center justify-content-center"><span
												class="fa fa-twitter"></span></a>
										</p>
									</div>
								</div>
								<form action="login" method="post" class="signin-form">
									<div class="form-group mt-3">
										<input name="user" type="text" class="form-control" required> <label
											class="form-control-placeholder" for="username">Username</label>
									</div>
									<div class="form-group">
										<input name="password" id="password-field" type="password" class="form-control"
											required> <label class="form-control-placeholder"
											for="password">Password</label> <span toggle="#password-field"
											class="fa fa-fw fa-eye field-icon toggle-password"></span>
									</div>
									<div class="form-group">
										<button type="submit"
											class="form-control btn btn-primary rounded submit px-3">Sign
											In</button>
									</div>
									<div class="form-group d-md-flex">
										<div class="w-50 text-left">
											<label class="checkbox-wrap checkbox-primary mb-0">Remember
												Me <input type="checkbox" value="Y" name="rememberMe"  checked> <span
												class="checkmark"></span>
											</label>
										</div>
										<div class="w-50 text-md-right">
											<a href="#">Forgot Password</a>
										</div>
									</div>
								</form>
								<p class="text-center">
									Not a member? <a href="register.jsp">Sign Up</a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	
	
	</body>
	</html>
	<%@ include file="footer.jsp"%>
