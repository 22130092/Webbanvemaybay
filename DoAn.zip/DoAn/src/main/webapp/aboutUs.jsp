<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    session = request.getSession();
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp"); // Redirect to login if not logged in
        return;
    }
%>
<div id="about-us-cover" class="has-bg section-container">
    <div class="cover-bg">
        <img src="images/a21.jpg" alt="Airline cover image" />
    </div>
    <div class="container">
        <ul class="breadcrumb f-s-12">
            <li><a href="index.jsp" data-key="home">Trang chủ</a></li>
            <li class="active" data-key="aboutUs">/ Về chúng tôi</li>
        </ul>

        <div class="about-us text-center">
            <h1 data-key="aboutUsTitle">Về Chúng Tôi</h1>
            <p data-key="aboutUsDescription">
                "Chúng tôi mang đến những chuyến bay an toàn, nhanh chóng và giá trị tuyệt vời cho khách hàng!"
            </p>
        </div>
    </div>
</div>

<div id="about-us-content" class="section-container bg-white">
    <div class="container">
        <div class="about-us-content">
            <h2 class="title text-center" data-key="whatWeDoTitle">Chúng Tôi Làm Gì?</h2>
            <p class="desc text-center" data-key="whatWeDoDescription">
                Chúng tôi cung cấp dịch vụ bán vé máy bay nhanh chóng, tiết kiệm và dễ dàng, giúp bạn có những chuyến bay tuyệt vời đến mọi miền của thế giới.
            </p>

            <div class="row">
                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-muted"><i class="fa fa-plane"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service1Title">Chuyến Bay Nhanh Chóng</h4>
                            <p class="desc" data-key="service1Description">Chúng tôi cung cấp những chuyến bay nhanh nhất với đội ngũ phi công và máy bay hiện đại, đảm bảo an toàn cho mỗi hành trình.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-primary"><i class="fa fa-dollar-sign"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service2Title">Giá Vé Cạnh Tranh</h4>
                            <p class="desc" data-key="service2Description">Chúng tôi cung cấp những mức giá vé hợp lý, giúp bạn tiết kiệm chi phí cho mỗi chuyến bay mà không phải hy sinh chất lượng dịch vụ.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-info"><i class="fa fa-cogs"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service3Title">Dịch Vụ Tiện Ích</h4>
                            <p class="desc" data-key="service3Description">Chúng tôi cung cấp các dịch vụ tiện ích đi kèm như chọn chỗ ngồi, dịch vụ ăn uống và giải trí trên chuyến bay, mang đến trải nghiệm tuyệt vời cho hành khách.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-danger"><i class="fa fa-calendar-check"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service4Title">Đặt Vé Dễ Dàng</h4>
                            <p class="desc" data-key="service4Description">Chúng tôi cung cấp hệ thống đặt vé trực tuyến đơn giản, dễ sử dụng, cho phép bạn lựa chọn và đặt vé chỉ trong vài phút.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-inverse"><i class="fa fa-globe"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service5Title">Mạng Lưới Đường Bay Phong Phú</h4>
                            <p class="desc" data-key="service5Description">Chúng tôi cung cấp các chuyến bay đến hàng nghìn địa điểm trên toàn thế giới, giúp bạn dễ dàng di chuyển tới bất kỳ đâu bạn muốn.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4">
                    <div class="service">
                        <div class="icon text-success"><i class="fa fa-headset"></i></div>
                        <div class="info">
                            <h4 class="title" data-key="service6Title">Hỗ Trợ 24/7</h4>
                            <p class="desc" data-key="service6Description">Chúng tôi luôn sẵn sàng hỗ trợ bạn 24/7, giải đáp mọi thắc mắc và đảm bảo chuyến bay của bạn luôn diễn ra suôn sẻ.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<%@ include file="footer.jsp"%>
