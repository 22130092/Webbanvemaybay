<%@ page import="org.apache.jasper.tagplugins.jstl.core.Import"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="model.*"%>
<%@ page import="dao.*"%>
<%@ page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Management</title>
<!-- Bootstrap CSS -->
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css"
	rel="stylesheet">
<!-- Custom CSS -->
<style>
body {
	font-family: 'Arial', sans-serif;
	background-color: #f8f9fa;
}

.container {
	margin-top: 20px;
}

.table thead {
	background-color: #343a40;
	color: white;
}

.actions a {
	margin-right: 10px;
	text-decoration: none;
}

.actions a.btn {
	padding: 5px 10px;
}
</style>
<!-- Bootstrap JS & jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script
	src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script
	src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
        function editUser(userId, username, fullName, email, phone, roleId) {
            document.getElementById('editUserId').value = userId;
            document.getElementById('editUsername').value = username;
            document.getElementById('editFullName').value = fullName;
            document.getElementById('editEmail').value = email;
            document.getElementById('editPhone').value = phone;
            document.getElementById('editRole').value = roleId;
        }
    </script>
<%
session = request.getSession();
User user = (User) session.getAttribute("user");

if (user == null) {
	response.sendRedirect("login.jsp");
	return;
}
if (user.getRoleId() == 2) {
	response.sendRedirect("index.jsp");
	return;
}
%>
</head>
<body> 
<%
				User usss = (User) session.getAttribute("user");
				if (usss != null) {
				%>
				<form action="logout" class="d-inline" style="position: absolute; top: 12px; left: 1200px; " >
    <div class="d-flex align-items-center">
        <span class="me-2" style="font-weight: bold; font-size: 16px; color: #333;"><%= usss.getFullName() %></span>
        <button type="submit" class="btn btn-outline-danger btn-sm" style="border-radius: 5px; padding: 5px 10px; font-size: 14px; font-weight: bold;">
            Đăng Xuất
        </button>
    </div>
</form>

				<%
				} else {
				%>
				<a href="login.jsp" class="btn btn-outline-primary btn-sm me-2">Đăng
					Nhập</a> <a href="register.jsp" class="btn btn-primary btn-sm">Đăng
					Ký</a>
				<%
				}
				%>
	<%
	String message = (String) session.getAttribute("message");
	if (message != null) {
	%>
	<div class="alert alert-info">
		<%=message%>
	</div>
	<%
	session.removeAttribute("message");
	}
	%>

	<div class="container mt-5">
		<div class="card mb-4">

			<div class="card-header bg-primary text-white">

				<h2>Quản Lý Người Dùng</h2>
			</div>
			<div class="card-body">
				<button class="btn btn-success" data-toggle="modal"
					data-target="#addUserModal">Thêm Người Dùng Mới</button>

				<table class="table table-hover mt-3">
					<thead>
						<tr>
							<th>ID Người Dùng</th>
							<th>Tên Người Dùng</th>
							<th>Họ Tên</th>
							<th>Email</th>
							<th>Số Điện Thoại</th>
							<th>Vai Trò</th>
							<th>Hành Động</th>
						</tr>
					</thead>
					<tbody>
						<%
						ArrayList<User> users = UserDAO.getInstance().selectAll();
						for (User u : users) {
						%>
						<tr>
							<td><%=u.getUserId()%></td>
							<td><%=u.getUsername()%></td>
							<td><%=u.getFullName()%></td>
							<td><%=u.getEmail()%></td>
							<td><%=u.getPhone()%></td>
							<td><%=u.getRoleId() == 1 ? "Admin" : "User"%></td>
							<td>
								<!-- Chỉnh sửa -->
								<button class="btn btn-warning btn-sm" data-toggle="modal"
									data-target="#editUserModal"
									onclick="editUser(<%=u.getUserId()%>, '<%=u.getUsername()%>', '<%=u.getFullName()%>', 
                                    '<%=u.getEmail()%>', '<%=u.getPhone()%>', <%=u.getRoleId()%>)">Chỉnh
									Sửa</button> <!-- Xóa -->
								<form action="deleteUser" method="POST" style="display: inline;">
									<input type="hidden" name="username" value="<%=u.getUsername()%>">
									<button type="submit" class="btn btn-danger btn-sm">Xóa</button>
								</form>
							</td>
						</tr>
						<%
						}
						%>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- Modal Thêm Người Dùng -->
	<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog"
		aria-labelledby="addUserModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="addUserModalLabel">Thêm Người Dùng
						Mới</h5>
					<button type="button" class="close" data-dismiss="modal"
						aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="addUser" method="POST">
						<div class="form-group">
							<label for="username">Tên Người Dùng</label> <input type="text"
								class="form-control" id="username" name="username" required>
						</div>
						<div class="form-group">
							<label for="password">Mật khẩu</label> <input type="password"
								class="form-control" id="password" name="password" required>
						</div>
						<div class="form-group">
							<label for="fullName">Họ Tên</label> <input type="text"
								class="form-control" id="fullName" name="fullName" required>
						</div>
						<div class="form-group">
							<label for="email">Email</label> <input type="email"
								class="form-control" id="email" name="email" required>
						</div>
						<div class="form-group">
							<label for="phone">Số Điện Thoại</label> <input type="text"
								class="form-control" id="phone" name="phone" required>
						</div>
						<div class="form-group">
							<label for="role">Vai Trò</label> <select class="form-control"
								id="role" name="role" required>
								<option value="1">Admin</option>
								<option value="2">User</option>
							</select>
						</div>
						<button type="submit" class="btn btn-success">Thêm Người
							Dùng</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal Chỉnh Sửa Người Dùng -->
	<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog"
		aria-labelledby="editUserModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="editUserModalLabel">Chỉnh Sửa
						Người Dùng</h5>
					<button type="button" class="close" data-dismiss="modal"
						aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="editUser" method="POST">
						<input type="hidden" id="editUserId" name="userId">
						<div class="form-group">
							<label for="editUsername">Tên Người Dùng</label> <input
								type="text" class="form-control" id="editUsername"
								name="username" required>
						</div>
						<div class="form-group">
							<label for="editFullName">Họ Tên</label> <input type="text"
								class="form-control" id="editFullName" name="fullName" required>
						</div>
						<div class="form-group">
							<label for="editEmail">Email</label> <input type="email"
								class="form-control" id="editEmail" name="email" required>
						</div>
						<div class="form-group">
							<label for="editPhone">Số Điện Thoại</label> <input type="text"
								class="form-control" id="editPhone" name="phone" required>
						</div>
						<div class="form-group">
							<label for="editRole">Vai Trò</label> <select
								class="form-control" id="editRole" name="role" required>
								<option value="1">Admin</option>
								<option value="2">User</option>
							</select>
						</div>
						<button type="submit" class="btn btn-warning">Lưu Thay
							Đổi</button>
					</form>
				</div>
			</div>
		</div>
	</div>



	<!-- Add User Modal -->
	<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog"
		aria-labelledby="addUserModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
					<button type="button" class="close" data-dismiss="modal"
						aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="addUser" method="POST">
						<div class="form-group">
							<label for="username">Username</label> <input type="text"
								class="form-control" id="username" name="username" required>
						</div>
						<div class="form-group">
							<label for="password">Password</label> <input type="password"
								class="form-control" id="password" name="password" required>
						</div>
						<div class="form-group">
							<label for="fullName">Full Name</label> <input type="text"
								class="form-control" id="fullName" name="fullName" required>
						</div>
						<div class="form-group">
							<label for="email">Email</label> <input type="email"
								class="form-control" id="email" name="email" required>
						</div>
						<div class="form-group">
							<label for="phone">Phone</label> <input type="text"
								class="form-control" id="phone" name="phone" required>
						</div>
						<div class="form-group">
							<label for="role">Role</label> <select class="form-control"
								id="role" name="role" required>
								<option value="1">Admin</option>
								<option value="2">User</option>
							</select>
						</div>
						<button type="submit" class="btn btn-success">Add User</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Edit User Modal -->
	<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog"
		aria-labelledby="editUserModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
					<button type="button" class="close" data-dismiss="modal"
						aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="editUser" method="POST">
						<input type="hidden" id="editUserId" name="userId">
						<div class="form-group">
							<label for="editUsername">Username</label> <input type="text"
								class="form-control" id="editUsername" name="username" required>
						</div>
						<div class="form-group">
							<label for="editFullName">Full Name</label> <input type="text"
								class="form-control" id="editFullName" name="fullName" required>
						</div>
						<div class="form-group">
							<label for="editEmail">Email</label> <input type="email"
								class="form-control" id="editEmail" name="email" required>
						</div>
						<div class="form-group">
							<label for="editPhone">Phone</label> <input type="text"
								class="form-control" id="editPhone" name="phone" required>
						</div>
						<div class="form-group">
							<label for="editRole">Role</label> <select class="form-control"
								id="editRole" name="role" required>
								<option value="1">Admin</option>
								<option value="2">User</option>
							</select>
						</div>
						<button type="submit" class="btn btn-warning">Save
							Changes</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Flight Management -->
<div class="container mt-5">
    <div class="card mb-4">
        <div class="card-header bg-secondary text-white">
            <h2>Quản Lý Chuyến Bay</h2>
        </div>
        <div class="card-body">
            <button class="btn btn-success" data-toggle="modal" data-target="#addFlightModal">Thêm Chuyến Bay Mới</button>

            <table class="table table-hover mt-3">
                <thead>
                    <tr>
                        <th>ID Chuyến Bay</th>
                        <th>Hãng Hàng Không</th>
                        <th>Số Hiệu Chuyến Bay</th>
                        <th>Thành Phố Khởi Hành</th>
                        <th>Thành Phố Đến</th>
                        <th>Giá</th>
                        <th>Số Ghế Còn Lại</th>
                        <th>Giờ Khởi Hành</th> <!-- New column for Departure Time -->
                        <th>Giờ Đến</th> <!-- New column for Arrival Time -->
                        <th>Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                    // Fetch flight data (adjust accordingly to your data fetching mechanism)
                    ArrayList<Flight> flights = FlightDAO.getInstance().selectAll();
                    for (Flight f : flights) {
                    %>
                    <tr>
                        <td><%= f.getFlightId() %></td>
                        <td><%= f.getAirline() %></td>
                        <td><%= f.getFlightNumber() %></td>
                        <td><%= f.getDepartureCity() %></td>
                        <td><%= f.getArrivalCity() %></td>
                        <td><%= f.getPrice() %></td>
                        <td><%= f.getSeatsAvailable() %></td>
                        <td><%= f.getDepartureTime() %></td> <!-- Display Departure Time -->
                        <td><%= f.getArrivalTime() %></td> <!-- Display Arrival Time -->
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal"
                                data-target="#editFlightModal"
                                onclick="editFlight(<%= f.getFlightId() %>, 
                                                    '<%= f.getAirline() %>', 
                                                    '<%= f.getFlightNumber() %>', 
                                                    '<%= f.getDepartureCity() %>', 
                                                    '<%= f.getArrivalCity() %>', 
                                                    <%= f.getPrice() %>, 
                                                    <%= f.getSeatsAvailable() %>, 
                                                    '<%= f.getDepartureTime() %>', 
                                                    '<%= f.getArrivalTime() %>')">
                                Chỉnh Sửa
                            </button>
                            <form action="deleteFlight" method="POST" style="display: inline;">
                                <input type="hidden" name="flightId" value="<%= f.getFlightId() %>">
                                <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                            </form>
                        </td>
                    </tr>
                    <%
                    }
                    %>
                </tbody>
            </table>
        </div>
    </div>
</div>

	<!-- Booking Management -->
	<div class="container mt-5">
		<div class="card mb-4">
			<div class="card-header bg-info text-white">
				<h2>Quản Lý Đặt Vé</h2>
			</div>
			<div class="card-body">
				<button class="btn btn-success" data-toggle="modal"
					data-target="#addBookingModal">Thêm Đặt Vé Mới</button>

				<table class="table table-hover mt-3">
					<thead>
						<tr>
							<th>ID Đặt Vé</th>
							<th>ID Người Dùng</th>
							<th>ID Chuyến Bay</th>
							<th>Số Ghế</th>
							<th>Tổng Giá</th>
							<th>Trạng Thái</th>
							<th>Hành Động</th>
						</tr>
					</thead>
					<tbody>
						<%
						// Fetch booking data (adjust accordingly to your data fetching mechanism)
						ArrayList<Booking> bookings = BookingDAO.getInstance().selectAll();
						for (Booking b : bookings) {
						%>
						<tr>
							<td><%=b.getBookingId()%></td>
							<td><%=b.getUserId()%></td>
							<td><%=b.getFlightId()%></td>
							<td><%=b.getNumberOfSeats()%></td>
							<td><%=b.getTotalPrice()%></td>
							<td><%=b.getBookingStatus()%></td>
							<td>
								<!-- Edit -->
								<button class="btn btn-warning btn-sm" data-toggle="modal"
									data-target="#editBookingModal"
									onclick="editBooking(<%=b.getBookingId()%>, <%=b.getUserId()%>, <%=b.getFlightId()%>, 
                            <%=b.getNumberOfSeats()%>, <%=b.getTotalPrice()%>, '<%=b.getBookingStatus()%>')">Chỉnh
									Sửa</button> <!-- Delete -->
								<form action="deleteBooking" method="POST"
									style="display: inline;">
									<input type="hidden" name="bookingId"
										value="<%=b.getBookingId()%>">
									<button type="submit" class="btn btn-danger btn-sm">Xóa</button>
								</form>
							</td>
						</tr>
						<%
						}
						%>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- Modal Thêm Chuyến Bay -->
<div class="modal fade" id="addFlightModal" tabindex="-1" role="dialog"
    aria-labelledby="addFlightModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addFlightModalLabel">Thêm Chuyến Bay Mới</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="addFlight" method="POST">
                    <div class="form-group">
                        <label for="airline">Hãng Hàng Không</label> 
                        <input type="text" class="form-control" id="airline" name="airline" required>
                    </div>
                    <div class="form-group">
                        <label for="flightNumber">Số Hiệu Chuyến Bay</label> 
                        <input type="text" class="form-control" id="flightNumber" name="flightNumber" required>
                    </div>
                    <div class="form-group">
                        <label for="departureCity">Thành Phố Khởi Hành</label> 
                        <input type="text" class="form-control" id="departureCity" name="departureCity" required>
                    </div>
                    <div class="form-group">
                        <label for="arrivalCity">Thành Phố Đến</label> 
                        <input type="text" class="form-control" id="arrivalCity" name="arrivalCity" required>
                    </div>
                    <div class="form-group">
                        <label for="departureTime">Giờ Khởi Hành</label> 
                        <input type="datetime-local" class="form-control" id="departureTime" name="departureTime" required>
                    </div>
                    <div class="form-group">
                        <label for="arrivalTime">Giờ Đến</label> 
                        <input type="datetime-local" class="form-control" id="arrivalTime" name="arrivalTime" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Giá</label> 
                        <input type="number" class="form-control" id="price" name="price" required>
                    </div>
                    <div class="form-group">
                        <label for="seatsAvailable">Số Ghế Còn Lại</label> 
                        <input type="number" class="form-control" id="seatsAvailable" name="seatsAvailable" required>
                    </div>
                    <button type="submit" class="btn btn-success">Thêm Chuyến Bay</button>
                </form>
            </div>
        </div>
    </div>
</div>


	<!-- Modal Chỉnh Sửa Chuyến Bay -->
<div class="modal fade" id="editFlightModal" tabindex="-1" role="dialog" aria-labelledby="editFlightModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editFlightModalLabel">Chỉnh Sửa Chuyến Bay</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="editFlight" method="POST">
                    <input type="hidden" id="editFlightId" name="flightId">
                    <div class="form-group">
                        <label for="editAirline">Hãng Hàng Không</label>
                        <input type="text" class="form-control" id="editAirline" name="airline" required>
                    </div>
                    <div class="form-group">
                        <label for="editFlightNumber">Số Hiệu Chuyến Bay</label>
                        <input type="text" class="form-control" id="editFlightNumber" name="flightNumber" required>
                    </div>
                    <div class="form-group">
                        <label for="editDepartureCity">Thành Phố Khởi Hành</label>
                        <input type="text" class="form-control" id="editDepartureCity" name="departureCity" required>
                    </div>
                    <div class="form-group">
                        <label for="editArrivalCity">Thành Phố Đến</label>
                        <input type="text" class="form-control" id="editArrivalCity" name="arrivalCity" required>
                    </div>
                    <div class="form-group">
                        <label for="editPrice">Giá</label>
                        <input type="number" class="form-control" id="editPrice" name="price" required>
                    </div>
                    <div class="form-group">
                        <label for="editSeatsAvailable">Số Ghế Còn Lại</label>
                        <input type="number" class="form-control" id="editSeatsAvailable" name="seatsAvailable" required>
                    </div>
                    <div class="form-group">
                        <label for="editDepartureTime">Giờ Khởi Hành</label>
                        <input type="text" class="form-control" id="editDepartureTime" name="departureTime">
                    </div>
                    <div class="form-group">
                        <label for="editArrivalTime">Giờ Đến</label>
                        <input type="text" class="form-control" id="editArrivalTime" name="arrivalTime">
                    </div>
                    <button type="submit" class="btn btn-warning">Lưu Thay Đổi</button>
                </form>
            </div>
        </div>
    </div>
</div>

	<script>
	function editFlight(flightId, airline, flightNumber, departureCity, arrivalCity, price, seatsAvailable, departureTime, arrivalTime) {
	    document.getElementById('editFlightId').value = flightId;
	    document.getElementById('editAirline').value = airline;
	    document.getElementById('editFlightNumber').value = flightNumber;
	    document.getElementById('editDepartureCity').value = departureCity;
	    document.getElementById('editArrivalCity').value = arrivalCity;
	    document.getElementById('editPrice').value = price;
	    document.getElementById('editSeatsAvailable').value = seatsAvailable;
	    document.getElementById('editDepartureTime').value = departureTime;
	    document.getElementById('editArrivalTime').value = arrivalTime;
	}


    function editBooking(bookingId, userId, flightId, seats, totalPrice, status) {
        document.getElementById('editBookingId').value = bookingId;
        document.getElementById('editUserId').value = userId;
        document.getElementById('editFlightId').value = flightId;
        document.getElementById('editSeats').value = seats;
        document.getElementById('editTotalPrice').value = totalPrice;
        document.getElementById('editStatus').value = status;
    }
</script>



	<!-- Bootstrap JS and dependencies -->
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
