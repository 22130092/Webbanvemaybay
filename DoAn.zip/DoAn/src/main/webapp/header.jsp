<%@ page import="model.User"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
	<%@ page import="dao.FlightDAO" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Flight" %>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Web Bán Vé Máy Bay - AirNL</title>

<!-- Script Bootstrap -->
<script
	src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Font Awesome -->
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<!-- Google Fonts -->
<link
	href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap"
	rel="stylesheet">

<!-- Bootstrap -->
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css"
	rel="stylesheet">

<!-- Custom CSS -->
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/style.css">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

	<!-- Header -->
</head>
<body>

	<!-- Header -->
	<header class="header">
		<div
			class="container d-flex justify-content-between align-items-center">
			<!-- Logo -->
			<a href="${pageContext.request.contextPath}/index.jsp"
				class="logo text-decoration-none text-light fw-bold fs-3"> AirNL
			</a>

			<!-- Navbar -->
			<nav class="navbar d-none d-lg-flex">
				<a class="nav-link"
					href="${pageContext.request.contextPath}/index.jsp" data-key="home">Trang
					Chủ</a>

				<!-- Vé Nội Địa Dropdown -->
				<%
				// Initialize FlightDAO and fetch the distinct departure cities
				FlightDAO flightDAO = FlightDAO.getInstance();
				ArrayList<String> departureCities = flightDAO.getDistinctDepartureCitiesDirect();
				%>

				<div class="dropdown">
					<a href="#" class="nav-link dropdown-toggle" id="navbarDropdown"
						role="button" data-bs-toggle="dropdown" aria-expanded="false"
						data-key="localFlight">Vé Nội Địa</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<%
						// Iterate over the departure cities and create dropdown items
						for (String city : departureCities) {
						%>
						<li><a class="dropdown-item" href="#"
							data-key="Vé Máy Bay Đi <%=city%>">Vé Máy Bay Đi <%=city%></a></li>
						<%
						}
						%>
					</ul>
				</div>

				<!-- Hỗ Trợ Dropdown -->
				<div class="dropdown">
					<a href="#" class="nav-link dropdown-toggle" id="navbarDropdown"
						role="button" data-bs-toggle="dropdown" aria-expanded="false"
						data-key="support">Hỗ Trợ</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item" href="faq.jsp" data-key="faq">FAQ</a></li>
						<li><a class="dropdown-item" href="contact.jsp"
							data-key="contact">Liên Hệ</a></li>
						<li><a class="nav-link" href="aboutUs.jsp" data-key="aboutUs">Giới
								Thiệu</a></li>
					</ul>
				</div>

				<!-- Language Dropdown -->
				<div class="dropdown">
					<a href="#" class="nav-link dropdown-toggle" id="languageDropdown"
						role="button" data-bs-toggle="dropdown" aria-expanded="false"
						data-key="language">Ngôn Ngữ</a>
					<ul class="dropdown-menu" aria-labelledby="languageDropdown">
						<li><a class="dropdown-item" href="#" data-lang="vi"
							data-key="vi">Tiếng Việt</a></li>
						<li><a class="dropdown-item" href="#" data-lang="en"
							data-key="en">English</a></li>
					</ul>
				</div>

				<%
				User u = (User) session.getAttribute("user");
				if (u != null) {
				%>
				<form action="logout" class="d-inline">
				    <a href="my_account.jsp" class="me-2 ">
				        <%= u.getFullName() %>
				    </a>
				    <button type="submit" class="btn btn-outline-danger btn-sm">Đăng Xuất</button>
				</form>

				<%
				} else {
				%>
				<a href="login.jsp" class="btn btn-outline-primary btn-sm me-2">Đăng
					Nhập</a> <a href="register.jsp" class="btn btn-primary btn-sm">Đăng
					Ký</a>
				<%
				}
				%>
			</nav>
		</div>
	</header>



	<script>
    $(document).ready(function () {
        // Load JSON file for languages
        $.getJSON('${pageContext.request.contextPath}/json.json', function (data) {
            // Language selection handler
            $('.dropdown-item').click(function () {
                const lang = $(this).data('lang');
                const selectedMessages = data[lang];

                // Update page content with selected language
                $('[data-key]').each(function () {
                    const key = $(this).data('key');
                    if (selectedMessages[key]) {
                        $(this).text(selectedMessages[key]);
                    }
                });

                // Update flight options
                $('.local-flight').each(function (index) {
                    $(this).text(selectedMessages.localFlight.options[index]);
                });

                $('.international-flight').each(function (index) {
                    $(this).text(selectedMessages.internationalFlight.options[index]);
                });

                $('.support').each(function (index) {
                    $(this).text(selectedMessages.support.options[index]);
                });
            });
        });
    });
</script>




</body>
</html>
