<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<footer class="footer">
    <div class="footer-container">
    <!-- Logo và thông tin công ty -->
    <div class="footer-about" data-key="footer-about">
        <h2 class="footer-logo" data-key="footer-logo">AirNL</h2>
        <p data-key="footer-about-description">AirNL cam kết mang đến cho bạn những chuyến bay an toàn, tiện nghi và đáng nhớ.</p>
        <p><strong data-key="footer-address">Địa chỉ:</strong> <span data-key="footer-address-value">Văn phòng Hà Nội</span></p>
        <p><strong data-key="footer-email">Email:</strong> <a href="mailto:info@airnl.com" data-key="footer-email-link">info@airnl.com</a></p>
        <p><strong data-key="footer-phone">Điện thoại:</strong> <a href="tel:0123456789" data-key="footer-phone-link">0123456789</a></p>
    </div>

    <!-- Liên kết nhanh -->
    <div class="footer-links" data-key="footer-links">
        <h3 data-key="f0">Liên kết nhanh</h3>
        <ul>
            <li><a href="/DoAn/index.jsp" data-key="f1">Trang chủ</a></li>
            <li><a href="/DoAn/aboutUs.jsp" data-key="footer-link-aboutUs">Giới thiệu</a></li>
            <li><a href="#" data-key="footer-link-services">Dịch vụ</a></li>
            <li><a href="/DoAn/faq.jsp" data-key="footer-link-faq">Câu hỏi thường gặp</a></li>
            <li><a href="/DoAn/contact.jsp" data-key="footer-link-contact">Liên hệ</a></li>
        </ul>
    </div>

    <!-- Mạng xã hội -->
    <div class="footer-social" data-key="footer-social">
        <h3 data-key="footer-social-title">Theo dõi chúng tôi</h3>
        <div class="social-icons">
            <a href="https://facebook.com/123456789.manhhung" target="_blank" class="icon" data-key="footer-icon-facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com" target="_blank" class="icon" data-key="footer-icon-twitter"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target="_blank" class="icon" data-key="footer-icon-instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target="_blank" class="icon" data-key="footer-icon-linkedin"><i class="fab fa-linkedin-in"></i></a>
        </div>
    </div>
</div>

<!-- Phần bản quyền -->
<div class="footer-bottom" data-key="footer-bottom">
    <p data-key="footer-copyright">&copy; 2025 AirNL. Mọi quyền được bảo lưu. Thiết kế bởi <a href="#" data-key="footer-design">AirNL Team</a>.</p>
</div>

</footer>

<!-- Bao gồm các thư viện JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
<script src="lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
