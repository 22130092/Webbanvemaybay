<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<div class="container">
    <h2>Cảm ơn bạn đã liên hệ!</h2>
    <p>Chúng tôi đã nhận được thông tin của bạn và sẽ phản hồi trong thời gian sớm nhất.</p>
    <a href="index.jsp" class="btn btn-primary">Trở về Trang Chủ</a>
</div>
<%@ include file="footer.jsp"%>