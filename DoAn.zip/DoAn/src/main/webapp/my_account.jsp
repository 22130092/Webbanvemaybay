<%@ page import="java.util.ArrayList" %>
<%@ page import="dao.BookingDAO" %>
<%@ page import="model.Booking" %>
<%@ page import="model.User" %>
<%@ page import="org.apache.jasper.tagplugins.jstl.core.Import"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tài Khoản Của Tôi</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/account.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Danh Sách Đặt Vé</h2>

    <%
        User user = (User) session.getAttribute("user");
        if (user != null) {
            int userId = user.getUserId();
            ArrayList<Booking> bookings = BookingDAO.getInstance().selectByCondition("UserID = " + userId);

            if (bookings != null && !bookings.isEmpty()) {
    %>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>Mã Đặt Vé</th>
                    <th>Mã Chuyến Bay</th>
                    <th>Số Ghế Đặt</th>
                    <th>Tổng Tiền</th>
                    <th>Trạng Thái</th>
                    <th>Ngày Đặt</th>
                </tr>
            </thead>
            <tbody>
                <%
                    for (Booking booking : bookings) {
                %>
                <tr>
                    <td><%= booking.getBookingId() %></td>
                    <td><%= booking.getFlightId() %></td>
                    <td><%= booking.getNumberOfSeats() %></td>
                    <td><%= booking.getTotalPrice() %> VND</td>
                    <td><%= booking.getBookingStatus() %></td>
                    <td><%= booking.getBookingDate() %></td>
                </tr>
                <%
                    }
                %>
            </tbody>
        </table>
    <%
            } else {
    %>
        <div class="alert alert-info text-center">Bạn chưa có đơn đặt vé nào.</div>
    <%
            }
        } else {
    %>
        <div class="alert alert-warning text-center">Vui lòng <a href="login.jsp"> đăng nhập</a> để xem thông tin đặt vé.</div>
    <%
        }
    %>
</div>

<!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Custom JS -->
<script src="js/account.js"></script>

</body>
<%@ include file="footer.jsp" %>
</html>
