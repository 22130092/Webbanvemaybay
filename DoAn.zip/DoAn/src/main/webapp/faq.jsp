<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    session = request.getSession();
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp"); // Redirect to login if not logged in
        return;
    }
%>
<div id="faq" class="section-container">
    <div class="container">
        <!-- Breadcrumb -->
        <ul class="breadcrumb m-b-10 f-s-12">
            <li><a href="index.jsp">Trang Chủ</a></li>
            <li class="active"> / FAQs</li>
        </ul>
        <h2>MỘT SỐ CÂU HỎI THƯỜNG GẶP !</h2>
        <!-- Panel Group -->
        <div class="accordion" id="faq-list">
            <!-- FAQ 1 -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-1">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-1" aria-expanded="true" aria-controls="faq-1" data-key="a1">
                        <i class="fa fa-question-circle fa-fw m-r-5"></i> 1. Làm thế nào để đặt vé máy bay?
                    </button>
                </h2>
                <div id="faq-1" class="accordion-collapse collapse show" aria-labelledby="heading-1" data-bs-parent="#faq-list">
                    <div class="accordion-body">
                        <p>
                            Để đặt vé máy bay, bạn chỉ cần thực hiện theo các bước sau:
                        </p>
                        <ul>
                            <li>Truy cập trang chủ và tìm kiếm chuyến bay theo nhu cầu.</li>
                            <li>Chọn chuyến bay phù hợp và nhấn "Đặt vé".</li>
                            <li>Điền thông tin cá nhân và chọn phương thức thanh toán.</li>
                            <li>Kiểm tra lại thông tin và nhấn "Xác nhận thanh toán".</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- FAQ 2 -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-2">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-2" aria-expanded="false" aria-controls="faq-2">
                        <i class="fa fa-question-circle fa-fw m-r-5"></i> 2. Tôi có thể thay đổi hoặc hủy vé đã đặt không?
                    </button>
                </h2>
                <div id="faq-2" class="accordion-collapse collapse" aria-labelledby="heading-2" data-bs-parent="#faq-list">
                    <div class="accordion-body">
                        <p>
                            Bạn có thể thay đổi hoặc hủy vé theo các chính sách sau:
                        </p>
                        <ul>
                            <li>Thay đổi vé: Trước giờ khởi hành 6 tiếng (có tính phí).</li>
                            <li>Hủy vé: Phải thực hiện trước 24 giờ kể từ thời gian khởi hành.</li>
                        </ul>
                        <p>Liên hệ bộ phận hỗ trợ để biết thêm chi tiết.</p>
                    </div>
                </div>
            </div>
            <!-- FAQ 3 -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-3">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-3" aria-expanded="false" aria-controls="faq-3">
                        <i class="fa fa-question-circle fa-fw m-r-5"></i> 3. Làm thế nào để kiểm tra tình trạng vé của tôi?
                    </button>
                </h2>
                <div id="faq-3" class="accordion-collapse collapse" aria-labelledby="heading-3" data-bs-parent="#faq-list">
                    <div class="accordion-body">
                        <p>
                            Sau khi đặt vé, bạn sẽ nhận được mã số đặt vé qua email hoặc tin nhắn. Sử dụng mã số này để:
                        </p>
                        <ul>
                            <li>Kiểm tra tình trạng vé trong mục "Quản lý vé" trên trang web.</li>
                            <li>Liên hệ với bộ phận hỗ trợ khách hàng để được cập nhật thông tin.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- FAQ 4 -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-4">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-4" aria-expanded="false" aria-controls="faq-4">
                        <i class="fa fa-question-circle fa-fw m-r-5"></i> 4. Chính sách hoàn vé và phí như thế nào?
                    </button>
                </h2>
                <div id="faq-4" class="accordion-collapse collapse" aria-labelledby="heading-4" data-bs-parent="#faq-list">
                    <div class="accordion-body">
                        <p>
                            Chính sách hoàn vé của chúng tôi như sau:
                        </p>
                        <ul>
                            <li>Hoàn vé sẽ chịu phí hoàn vé theo quy định của hãng hàng không.</li>
                            <li>Vé hoàn được bảo lưu giá trị trong vòng 1 năm.</li>
                            <li>Vui lòng thông báo hoàn vé trước 24 giờ để được hỗ trợ nhanh nhất.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- FAQ 5 -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-5">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-5" aria-expanded="false" aria-controls="faq-5">
                        <i class="fa fa-question-circle fa-fw m-r-5"></i> 5. Có hỗ trợ khách hàng 24/7 không?
                    </button>
                </h2>
                <div id="faq-5" class="accordion-collapse collapse" aria-labelledby="heading-5" data-bs-parent="#faq-list">
                    <div class="accordion-body">
                        <p>
                            Bộ phận hỗ trợ khách hàng của chúng tôi làm việc 24/7 để hỗ trợ bạn qua các kênh:
                        </p>
                        <ul>
                            <li>Email: support@airlinesupport.com</li>
                            <li>Điện thoại: 1900 123 456</li>
                            <li>Chat trực tuyến trên website.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<%@ include file="footer.jsp"%>
