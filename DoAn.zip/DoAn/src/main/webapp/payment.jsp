<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="header.jsp"%>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/search.css">
<head>
    <title>Thông Tin Thanh Toán</title>
</head>
<body>
    <h2>Thông Tin Thanh Toán</h2>
    <div class="container">
        <!-- Bảng Thông Tin Người Dùng -->
        <div class="table-container">
            <h3>Thông Tin Người Dùng</h3>
            <table class="table_search">
                <tr>
                    <th>Họ và Tên</th>
                    <td><%=request.getAttribute("userFullName")%></td>
                </tr>
                <tr>
                    <th>Tên Đăng Nhập</th>
                    <td><%=request.getAttribute("userName")%></td>
                </tr>
                <tr>
                    <th>Số Điện Thoại</th>
                    <td><%=request.getAttribute("userPhone")%></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><%=request.getAttribute("userEmail")%></td>
                </tr>
                <tr>
                    <th>Số Người đi</th>
                    <td>
                        <div class="form-group">
                            <select name="adultsAndChildren" id="peopleCount" onchange="updateTotal()">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                            </select>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th>Tổng tiền</th>
                    <td id="totalPrice">111</td>
                </tr>
            </table>
        </div>

        <script>
            // Hàm để tính tổng tiền và cập nhật hiển thị
            function updateTotal() {
                // Lấy giá vé của mỗi người từ phần tử ticketPrice (dưới dạng số)
                var pricePerPerson = parseFloat(document.getElementById("ticketPrice").textContent);

                // Lấy số người từ dropdown
                var peopleCount = document.getElementById("peopleCount").value;

                // Tính tổng tiền
                var total = pricePerPerson * peopleCount;

                // Cập nhật tổng tiền vào ô hiển thị trên giao diện
                document.getElementById("totalPrice").textContent = total;

                // Gán giá trị tổng tiền vào input hidden
                document.getElementById("hiddenTotal").value = total;

                // Gán giá trị số người đi vào input hidden
                document.getElementById("hiddenPeopleCount").value = peopleCount;
            }

            // Cập nhật tổng tiền khi trang được tải
            window.onload = updateTotal;
        </script>

        <!-- Bảng Thông Tin Chuyến Bay -->
        <div class="table-container">
            <h3>Thông Tin Chuyến Bay</h3>
            <table class="table_search">
                <tr>
                    <th>Hãng Bay</th>
                    <td><%=request.getAttribute("airline")%></td>
                </tr>
                <tr>
                    <th>Mã Chuyến Bay</th>
                    <td><%=request.getAttribute("flightNumber")%></td>
                </tr>
                <tr>
                    <th>Thành Phố Đi</th>
                    <td><%=request.getAttribute("departureCity")%></td>
                </tr>
                <tr>
                    <th>Thành Phố Đến</th>
                    <td><%=request.getAttribute("arrivalCity")%></td>
                </tr>
                <tr>
                    <th>Thời Gian Đi</th>
                    <td><%=request.getAttribute("departureTime")%></td>
                </tr>
                <tr>
                    <th>Thời Gian Đến</th>
                    <td><%=request.getAttribute("arrivalTime")%></td>
                </tr>
                <tr>
                    <th>Giá Vé (1 người)</th>
                    <td id="ticketPrice"><%=request.getAttribute("price")%></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <!-- Form for confirmation button inside the table -->
                        <form action="confirmBookingServlet" method="post">
                            <input type="hidden" name="userFullName" value="<%=request.getAttribute("userFullName")%>">
                            <input type="hidden" name="userName" value="<%=request.getAttribute("userName")%>">
                            <input type="hidden" name="userPhone" value="<%=request.getAttribute("userPhone")%>">
                            <input type="hidden" name="userEmail" value="<%=request.getAttribute("userEmail")%>">
                            <input type="hidden" name="airline" value="<%=request.getAttribute("airline")%>">
                            <input type="hidden" name="flightNumber" value="<%=request.getAttribute("flightNumber")%>">
                            <input type="hidden" name="departureCity" value="<%=request.getAttribute("departureCity")%>">
                            <input type="hidden" name="arrivalCity" value="<%=request.getAttribute("arrivalCity")%>">
                            <input type="hidden" name="departureTime" value="<%=request.getAttribute("departureTime")%>">
                            <input type="hidden" name="arrivalTime" value="<%=request.getAttribute("arrivalTime")%>">
                            <input type="hidden" name="flightID" value="<%=request.getAttribute("flightID")%>">
                            <input type="hidden" name="price" value="<%=request.getAttribute("price")%>">

                            <!-- Thêm input hidden cho tổng tiền -->
                            <input type="hidden" name="totalPrice" id="hiddenTotal" value="">

                            <!-- Thêm input hidden cho số người -->
                            <input type="hidden" name="peopleCount" id="hiddenPeopleCount" value="">

                            <button type="submit" class="btn-confirm">Xác Nhận Đặt Vé</button>
                        </form>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
<%@ include file="footer.jsp"%>
</html>
