<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%
    session = request.getSession();
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp"); // Redirect to login if not logged in
        return;
    }
%>
<div class="container">
	<!-- Breadcrumb -->
	<ul class="breadcrumb f-s-14">
		<li><a href="index.jsp">Trang Chủ</a></li>
		<li class="active">/ Liên Hệ</li>
	</ul>

	<div class="row">
		<!-- Form Liên Hệ -->
		<div class="col-md-8">
			<h4>Liên Hệ Với Chúng Tôi</h4>
			<p>Chúng tôi rất mong nhận được ý kiến và câu hỏi của bạn! Hãy
				điền vào biểu mẫu dưới đây, chúng tôi sẽ trả lời bạn nhanh nhất có
				thể.</p>
			<form method="post" action="contactServlet">
				<div class="form-group">
					<label>Tên Của Bạn <span class="text-danger">*</span></label> <input
						type="text" class="form-control" name="name" required />
				</div>
				<div class="form-group">
					<label>Email Của Bạn <span class="text-danger">*</span></label> <input
						type="email" class="form-control" name="email" required />
				</div>
				<div class="form-group">
					<label>Chủ Đề <span class="text-danger">*</span></label> <input
						type="text" class="form-control" name="subject" required />
				</div>
				<div class="form-group">
					<label>Thông Điệp <span class="text-danger">*</span></label>
					<textarea class="form-control" rows="5" name="message" required></textarea>
				</div>
				<button type="submit" class="btn btn-primary"style="margin:10px;">Gửi Tin Nhắn</button>
			</form>
		</div>
	</div>
</div>

<%@ include file="footer.jsp"%>