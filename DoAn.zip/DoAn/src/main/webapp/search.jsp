<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Flight" %>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/search.css">
<head>
    <title>Kết Quả Tìm Kiếm</title>
    <link rel="stylesheet" href="search_results.css"> <!-- Liên kết file CSS mới -->
</head>
<body>
    <h1 class="search-results-title" style="margin:30px">Kết Quả Tìm Kiếm</h1>
    <table class="search-results-table">
        <thead>
            <tr>
                <th class="search-results-header" >Hãng Bay</th>
                <th class="search-results-header">Mã Chuyến</th>
                <th class="search-results-header">Điểm Đi</th>
                <th class="search-results-header">Điểm Đến</th>
                <th class="search-results-header">Giờ Khởi Hành</th>
                <th class="search-results-header">Giờ Đến</th>
                <th class="search-results-header">Giá</th>
                <th class="search-results-header">Số Ghế Còn</th>
                <th class="search-results-header">Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <%
                ArrayList<Flight> flights = (ArrayList<Flight>) request.getAttribute("flights");
                if (flights != null && !flights.isEmpty()) {
                    for (Flight flight : flights) {
            %>
            <tr>
                <td class="search-results-data"><%= flight.getAirline() %></td>
                <td class="search-results-data"><%= flight.getFlightNumber() %></td>
                <td class="search-results-data"><%= flight.getDepartureCity() %></td>
                <td class="search-results-data"><%= flight.getArrivalCity() %></td>
                <td class="search-results-data"><%= flight.getDepartureTime() %></td>
                <td class="search-results-data"><%= flight.getArrivalTime() %></td>
                <td class="search-results-data"><%= String.format("%,.0f VND", flight.getPrice()) %></td>
                <td class="search-results-data"><%= flight.getSeatsAvailable() %></td>
                <td class="search-results-action">
                    <form action="BookingServlet" method="POST">
                        <input type="hidden" name="flightNumber" value="<%= flight.getFlightNumber() %>">
                        <input type="hidden" name="price" value="<%= flight.getPrice() %>">
                        <input type="hidden" name="airline" value="<%= flight.getAirline() %>">
                        <input type="hidden" name="departureCity" value="<%= flight.getDepartureCity() %>">
                        <input type="hidden" name="arrivalCity" value="<%= flight.getArrivalCity() %>">
                        <input type="hidden" name="departureTime" value="<%= flight.getDepartureTime() %>">
                        <input type="hidden" name="arrivalTime" value="<%= flight.getArrivalTime() %>">
                        <input type="hidden" name="flightID" value="<%= flight.getFlightId() %>">
                        <button type="submit" class="btn-book"style="">Đặt Vé</button>
                    </form>
                </td>
            </tr>
            <%
                    }
                } else {
            %>
            <tr>
                <td colspan="9" style="text-align: center;" class="search-results-no-flight">Không tìm thấy chuyến bay nào.</td>
            </tr>
            <%
                }
            %>
        </tbody>
    </table>
</body>
<%@ include file="footer.jsp" %>
</html>
