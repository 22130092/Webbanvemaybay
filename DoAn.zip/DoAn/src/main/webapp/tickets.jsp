<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Tickets</title>
</head>
<body>
    <div class="booking-container">
        <div class="main-content">
            <div class="flight-info">    
                <div class="left-column">
                    <p>TP Hồ Chí Minh ➝ Hà Nội</p>
                    <p>Vietjet Air | VJ170 | 23:00 - 01:10</p>
                    <p>Máy bay: Airbus A321</p>
                </div>
                <div class="middle-column">
                    <p>Thứ Hai</p>
                    <p>Ngày: 12/01/2025</p>
                    <p>Giờ: 23:00 - 01:10</p>
                </div>
                <div class="price-info">
                    <div class="right-column">
                        <p>Vé người lớn x 1 = <strong>890,000 đ</strong></p>
                        <p>Thuế + phí = <strong>776,000 đ</strong></p>
                        <p class="total-price">Tổng giá vé = <strong>1,666,000 đ</strong></p>
                    </div>
                </div>
            </div>
            <div class="ticket-conditions">
			    <h3>Điều kiện vé</h3>
			    <ul>
			        <li><strong>Hoàn vé:</strong>
			            <ul>
			                <li>Thu phí, hoàn bảo lưu định danh trong 01 năm từ ngày khởi hành</li>
			                <li>Yêu cầu hoàn hủy phải báo trước 30 tiếng so với giờ khởi hành chặng bay đầu tiên</li>
			            </ul>
			        </li>
			        <li><strong>Đổi vé:</strong>
			            <ul>
			                <li>Trước giờ khởi hành 06 tiếng: 378,000đ/chiều/khách + chênh lệch giá</li>
			                <li>Trong vòng 06 tiếng và sau khởi hành: Không áp dụng</li>
			            </ul>
			        </li>
			        <li><strong>Đổi tên:</strong> Không áp dụng</li>
			    </ul>
			</div>
            

           <div class="passenger-info">
			    <div class="form-row">
			        <select id="baggage">
			            <option value="0">Anh</option>
			            <option value="0">Chị</option>
			            <option value="0">Ông</option>
			            <option value="0">Bà</option>
			        </select>
			
			         <div class="input-group">
			            <label for="passenger-name">Họ và tên người bay:</label>
			            <input type="text" id="passenger-name" placeholder="vd: Nguyen Van An">
        			</div>
					<div class="input-group">
			        <label for="baggage">Hành lý ký gửi:</label>
			        <select id="baggage">
			            <option value="0">Mua thêm ký gửi</option>
			            <option value="0">Mua 20Kg-200,000 đ</option>
			            <option value="0">Mua 30Kg-300,000 đ</option>
			            <option value="0">Mua 40Kg-400,000 đ</option>
			            <option value="0">Mua 50Kg-500,000 đ</option>
			            <option value="0">Mua 60Kg-600,000 đ</option>
			            <option value="0">Mua 70Kg-700,000 đ</option>
			        </select>
			        </div>
			
			        <select id="baggage">
			            <option value="0">Thêm Khách</option>
			        </select>
			    </div>
			
			    <p class="note">Giá vé chưa bao gồm hành lý ký gửi.<br>Mua hành lý bây giờ, hoặc có thể mua sau.</p>
			</div>


				<div class="contact-info">
				    <h3>Thông tin liên hệ</h3>
				
				    <div class="input-group">
				        <label for="contact-name">Tên liên hệ:</label>
				        <input type="text" id="contact-name">
				    </div>
				
				    <div class="input-group">
				        <label for="contact-phone">Điện thoại:</label>
				        <input type="text" id="contact-phone" required>
				    </div>
				
				    <div class="input-group">
				        <label for="contact-email">Email:</label>
				        <input type="email" id="contact-email">
				    </div>
				
				    <div class="options">
				        <div class="option">
				            <input type="checkbox" id="invoice-request">
				            <label for="invoice-request">Yêu cầu xuất hóa đơn</label>
				        </div>
				
				        <div class="option">
				            <input type="checkbox" id="order-note">
				            <label for="order-note">Ghi chú về đơn hàng</label>
				        </div>
				    </div>
				    
				</div>


            <div class="actions">
                <button class="btn primary">Chọn Lại Chuyến Bay</button>
                <button class="btn primary">ĐẶT VÉ</button>
            </div>

            <div class="ticket-summary">
                <p><strong>Vietjet Air</strong> | Thứ Hai 13/01 | SGN 23:00 - HAN 01:10</p>
                <p>(chưa có hành lý ký gửi)</p>
            </div>
            <div class="note">
			    <h3>Bước tiếp theo:</h3>
			    <ul>
			        <li>Vé điện tử sẽ được gửi vào <strong>điện thoại</strong> và <strong>email</strong> ngay sau khi quý khách hoàn tất thanh toán.</li>
			        <li>Thanh toán linh hoạt qua <strong>mã QR</strong>, <strong>chuyển khoản</strong>, <strong>thẻ nội địa/quốc tế</strong>, <strong>ví điện tử</strong>, <strong>Payoo</strong>,...</li>
			        <li>Nếu quý khách cần hỗ trợ, vui lòng liên hệ <strong>19006091</strong>. Tổng đài <strong>Abay</strong> phục vụ <strong>24/7</strong> (không nghỉ).</li>
			    </ul>
			</div>
        </div>
    </div>
</body>

</html>