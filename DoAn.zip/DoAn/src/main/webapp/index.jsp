<%@ include file="header.jsp"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
	<%
    session = request.getSession();
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp"); // Redirect to login if not logged in
        return;
    }
%>
<style>
        .container {
            display: flex;
            justify-content: space-between; /* Tạo khoảng cách đều giữa các phần tử */
            align-items: flex-start; /* Căn đỉnh của ảnh và bảng */
            gap: 2px; /* Khoảng cách giữa ảnh và bảng */
        }

        .image-container {
            flex: 1; /* Ảnh chiếm 50% */
            display: flex;
            justify-content: center; /* Căn giữa ảnh theo chiều ngang */
            align-items: center; /* Căn giữa ảnh theo chiều dọc */
        }

        .image-container img {
        	margin:25px;
            max-width: 100%;
            height: 550px;
            border-radius: 8px;
            margin-left:20px;
        }

        .table-container {
            flex: 1; /* Bảng chiếm 50% */
        }

        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-container th,
        .table-container td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .table-container th {
            background-color: #33CCCC;
            color: white;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .search-btn {
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #33CCCC;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #28a8a8;
        }
    </style>
<div class="container">
<div class="image-container" >
	<img src="images/b1.jpg" alt="Banner Image" class="banner-img">
</div>	

<div class="table_search"style="width: 50%;
    padding: 12px;
    color: black;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
">
    <div class="flight-booking" style="justify-content: center;">
        <table class="tab-table"style="width:100%;font-size: 16px;
            margin-bottom: 15px;
		    font-weight: bold;
		    margin-bottom: 5px;
		    background: #33CCCC;">
    <tr>
        <td class="tab-cell active">Đặt Vé Ngay</td>
    </tr>
</table>
        <%

            ArrayList<String> arrivalCities = flightDAO.getDistinctArrivalCities();
            ArrayList<String> airlines = flightDAO.getDistinctAirlines();
        %>
        <form class="form" action="Search" method="post">
             <div class="form-group"style="font-size: 16px;
            margin-bottom: 15px;
		    font-weight: bold;
		    margin-bottom: 5px;
		    display: block;
            ">
                <label>Từ</label>
                <select name="DepartureCity">
                    <!-- Tên tham số đúng -->
                    <%
                        for (String city : departureCities) {
                    %>
                    <option value="<%=city%>"><%=city%></option>
                    <%
                        }
                    %>
                </select>
            </div>

             <div class="form-group"style="font-size: 16px;
            margin-bottom: 15px;
		    font-weight: bold;
		    margin-bottom: 5px;
		    display: block;
            ">
                <label>Đến</label>
                <select name="ArrivalCity">
                    <!-- Tên tham số đúng -->
                    <%
                        for (String city : arrivalCities) {
                    %>
                    <option value="<%=city%>"><%=city%></option>
                    <%
                        }
                    %>
                </select>
            </div>

            <div class="form-group"style="font-size: 16px;
            margin-bottom: 15px;
		    font-weight: bold;
		    margin-bottom: 5px;
		    display: block;
            ">
                <label>Hãng Hàng Không</label>
                <select name="Airline">
                    <!-- Tên tham số đúng nếu cần -->
                    <%
                        for (String airline : airlines) {
                    %>
                    <option value="<%=airline%>"><%=airline%></option>
                    <%
                        }
                    %>
                </select>
            </div>
          

             <div class="form-group"style="font-size: 16px;
            margin-bottom: 15px;
		    font-weight: bold;
            ">
                <label>Ngày Khởi Hành</label>
                <input type="date" name="departureDate" />
                <!-- Đảm bảo tên đúng -->
            </div>
          

            <!-- Các trường khác của form -->
            <button type="submit" class="search-btn" style="margin-left:150px ; background: #33CCCC; ">Tìm Chuyến Bay</button>
        </form>
    </div>
</div>
</div>


	<%
	flightDAO = FlightDAO.getInstance();
	ArrayList<Flight> promotionalFlights = flightDAO.getPromotionalFlights("Hồ Chí Minh");
	System.out.println("Number of promotional flights: " + promotionalFlights.size());
	%>

<div class="promotion-container">
	<h2>VÉ MÁY BAY KHUYẾN MÃI</h2>
	<div class="tab-menu">
		<button class="active">Thành Phố Hồ Chí Minh</button>
		<button>Hà Nội</button>
		<button>Đà Nẵng</button>
		<button>Phú Quốc</button>
		<button>Quốc Tế</button>
	</div>
	<div class="card-container">
		<%
		// Iterate over the promotional flights and display them
		for (Flight flight : promotionalFlights) {
		%>
		<div class="card">
			<h3><%=flight.getArrivalCity()%></h3>
			<p>
				Từ
				<%=flight.getDepartureCity()%></p>
			<p><%=flight.getDepartureTime()%>
				->
				<%=flight.getArrivalTime()%></p>
			<p class="price">
				Giá từ <strong><%=flight.getPrice()%> VND</strong>
			</p>
		</div>
		<%
		}
		%>
	</div>
</div>

<%@ include file="footer.jsp"%>
