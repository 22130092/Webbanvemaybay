package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import dao.FlightDAO;
import model.Flight;

@WebServlet("/Search")
public class Search extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Search() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy thông tin từ form
        String fromCity = request.getParameter("DepartureCity");
        String toCity = request.getParameter("ArrivalCity");
        String departureDate = request.getParameter("departureDate");

        try {
            // Sử dụng FlightDAO để lấy danh sách chuyến bay
            FlightDAO flightDAO = FlightDAO.getInstance();
            ArrayList<Flight> flights = flightDAO.searchFlights(fromCity, toCity, departureDate);

            // Truyền danh sách chuyến bay sang JSP
            request.setAttribute("flights", flights);
            request.getRequestDispatcher("search.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Có lỗi xảy ra trong quá trình tìm kiếm chuyến bay");
        }
    }


}
