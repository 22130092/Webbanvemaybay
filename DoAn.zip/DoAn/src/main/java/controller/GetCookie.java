package controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.User;

public class GetCookie {
    private static final String ATT_NAME_USER_NAME = "USER_NAME_COOKIE";

    // Lưu thông tin người dùng vào Cookie
    public static void storeUserCookie(HttpServletResponse response, User user) {
        Cookie cookieUserName = new Cookie(ATT_NAME_USER_NAME, user.getUsername());
        cookieUserName.setMaxAge(24 * 60 * 60); // 1 ngày
        response.addCookie(cookieUserName);
    }

    // Lấy thông tin người dùng từ Cookie
    public static String getUserNameInCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (ATT_NAME_USER_NAME.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    // Xóa Cookie
    public static void deleteUserCookie(HttpServletResponse response) {
        Cookie cookieUserName = new Cookie(ATT_NAME_USER_NAME, null);
        cookieUserName.setMaxAge(0); // Cookie hết hiệu lực ngay lập tức
        response.addCookie(cookieUserName);
    }
}
