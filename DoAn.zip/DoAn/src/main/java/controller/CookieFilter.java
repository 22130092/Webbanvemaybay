package controller;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import model.User;
import dao.UserDAO;

@WebFilter(filterName = "cookieFilter", urlPatterns = { "/*" })
public class CookieFilter implements Filter {

    public CookieFilter() {}

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession(false); // Không tự động tạo session mới
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        // Nếu user đã có trong session, tiếp tục xử lý
        if (user != null) {
            chain.doFilter(request, response);
            return;
        }

        // Kiểm tra cookie nếu session chưa chứa user
        String username = GetCookie.getUserNameInCookie(req);
        if (username != null) {
            UserDAO userDAO = new UserDAO();
            User userFromDb = userDAO.getUserByUsername(username);

            if (userFromDb != null) {
                // Lưu thông tin user (customer hoặc admin) vào session
                if (session == null) {
                    session = req.getSession();
                }
                session.setAttribute("user", userFromDb);
            }
        }

        chain.doFilter(request, response);
    }
}
