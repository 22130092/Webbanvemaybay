package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Booking;
import model.User;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.io.IOException;
import java.util.Properties;

import dao.BookingDAO;

@WebServlet("/confirmBookingServlet")
public class ConfirmBookingServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userFullName = request.getParameter("userFullName");
        String userName = request.getParameter("userName");
        String userPhone = request.getParameter("userPhone");
        String userEmail = request.getParameter("userEmail"); // Địa chỉ email từ form
        String airline = request.getParameter("airline");
        String flightNumber = request.getParameter("flightNumber");
        String departureCity = request.getParameter("departureCity");
        String arrivalCity = request.getParameter("arrivalCity");
        String departureTime = request.getParameter("departureTime");
        String arrivalTime = request.getParameter("arrivalTime");
        String price = request.getParameter("price");
        String totalPrice = request.getParameter("totalPrice");
        String peopleCount = request.getParameter("peopleCount");
        
        
        String  flightId = request.getParameter("flightID");  // Example flightId, you should fetch this from database or request
        HttpSession session = request.getSession();
        User u  = (User) session.getAttribute("user");

        // Create a new Booking object
        System.out.println(flightId);
        System.out.println(peopleCount);
        System.out.println(totalPrice);
        Booking booking = new Booking(u.getUserId(), Integer.parseInt(flightId), Integer.parseInt(peopleCount), Integer.parseInt(totalPrice), "Confirmed");

        // Save the booking into the database
        BookingDAO bookingDAO = BookingDAO.getInstance();
       System.out.println(booking);
        bookingDAO.insert(booking);

        // Gửi email xác nhận đến người dùng
        sendConfirmationEmail(price, userEmail, userFullName, flightNumber, airline, departureTime, arrivalTime, departureCity, arrivalCity,totalPrice);

        // Gửi thông báo cho admin (thêm địa chỉ admin vào)
        sendAdminNotification(flightNumber, userFullName, userPhone, userEmail,price);

        // Redirect to the booking confirmation page
        response.sendRedirect("index.jsp");
    }

    private void sendConfirmationEmail(String price, String userEmail, String userFullName, String flightNumber, String airline, String departureTime, String arrivalTime, String departureCity, String arrivalCity, String totalPrice) {
        String subject = "Booking Confirmation - Flight " + flightNumber;
        String body = "Dear " + userFullName + ",\n\n"
                + "Thank you for booking with us. Here are your flight details:\n\n"
                + "Flight Number: " + flightNumber +"\n"
                + "Airline: " + airline +"\n"
                + "Departure City: " + departureCity +"\n"
                + "Arrival City: " + arrivalCity +"\n"
                + "Departure Time: " + departureTime+"\n"
                + "Arrival Time: " + arrivalTime +"\n"
                 + "Price 1 ticket: " + price +"\n"
                 + "Total Price: " + totalPrice +"\n"
                + "We look forward to having you on board!\n"
                + "Best Regards,\n"
                + "The Booking Team";
        try {
            // Set up email properties
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");  // SMTP host for Gmail
            props.put("mail.smtp.port", "587");  // SMTP port for Gmail
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");

            // Authenticator for email account (Gmail)
            Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("avcbvc99@gmail.com", "hggz fqgo ipbb isln");  // Tài khoản và mật khẩu ứng dụng
                }
            });

            // Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("avcbvc99@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(userEmail));  // Gửi đến email của người dùng
            message.setSubject(subject);
            message.setText(body);

            // Send email
            Transport.send(message);
            System.out.println("Confirmation email sent successfully to " + userEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    private void sendAdminNotification(String flightNumber, String userFullName, String userPhone, String userEmail, String price) {
        String subject = "New Booking Notification";
        String body = "A new booking has been made. Here are the details:\n\n"
                + "Flight Number: " + flightNumber + "\n"
                + "User Full Name: " + userFullName + "\n"
                + "User Phone: " + userPhone + "\n"
                + "User Email: " + userEmail + "\n"
                + "Price: " + price + "\n\n"  // Thêm thông tin giá vé vào email admin
                + "Please review the booking.";
        try {
            // Set up email properties for admin notification
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");  // SMTP host for Gmail
            props.put("mail.smtp.port", "587");  // SMTP port for Gmail
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");

            // Authenticator for email account (Gmail)
            Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("avcbvc99@gmail.com", "hggz fqgo ipbb isln");  // Tài khoản và mật khẩu ứng dụng
                }
            });

            // Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("avcbvc99@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("churongcon123@gmail.com"));  // Địa chỉ email admin
            message.setSubject(subject);
            message.setText(body);

            // Send email
            Transport.send(message);
            System.out.println("Admin notification email sent successfully.");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

}
