package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import dao.UserDAO;
import model.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		User user = (session != null) ? (User) session.getAttribute("user") : null;

		if (user != null) {
			response.sendRedirect("index.jsp");
		} else {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("user");
		String password = request.getParameter("password");
		String rememberMeStr = request.getParameter("rememberMe");
		boolean remember = "Y".equalsIgnoreCase(rememberMeStr);

		try {
			UserDAO userDAO = UserDAO.getInstance();
			User user = userDAO.login(username, password);

			if (user != null) {
				// Lưu thông tin user (customer hoặc admin) vào session
				HttpSession session = request.getSession();
				session.setAttribute("user", user);

				// Lưu thông tin cookie nếu "Remember Me" được chọn
				if (remember) {
					GetCookie.storeUserCookie(response, user);
				} else {
					GetCookie.deleteUserCookie(response);
				}

				// Điều hướng dựa trên vai trò
				if (user.getRoleId() == 1) {
					response.sendRedirect("admin.jsp"); // Trang admin
				} else {
					response.sendRedirect("index.jsp"); // Trang người dùng
				}
			} else {
				// Sai tên đăng nhập hoặc mật khẩu
				request.setAttribute("error", "Invalid username or password");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"An error occurred while processing your request.");
		}
	}
}
