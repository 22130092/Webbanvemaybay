package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;

import java.io.IOException;

import dao.UserDAO;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {
	    try {
	        String username = request.getParameter("user");
	        String password = request.getParameter("password");
	        String email = request.getParameter("email");
	        String phone = request.getParameter("phone");
	        String fullName = request.getParameter("fullname");

	        if (username == null || password == null || email == null || phone == null || fullName == null ||
	                username.isEmpty() || password.isEmpty() || email.isEmpty() || phone.isEmpty() || fullName.isEmpty()) {
	            request.setAttribute("error", "All fields are required!");
	            request.getRequestDispatcher("register.jsp").forward(request, response);
	            return;
	        }

	        UserDAO userDAO = UserDAO.getInstance();

	        // Kiểm tra username đã tồn tại
	        if (userDAO.isUsernameTaken(username)) {
	            request.setAttribute("error", "Username is already taken. Please choose another.");
	            request.getRequestDispatcher("register.jsp").forward(request, response);
	            return;
	        }

	        // Tạo đối tượng User
	        User user = new User();
	        user.setUsername(username);
	        user.setPasswordHash(password);
	        user.setEmail(email);
	        user.setPhone(phone);
	        user.setFullName(fullName);
	        user.setRoleId(2);

	        // Chèn người dùng vào cơ sở dữ liệu
	        int result = userDAO.insert(user);

	        if (result > 0) {
	            request.setAttribute("error", "Registration successful! You can now log in.");
	        } else {
	            request.setAttribute("error", "Registration failed! Please try again.");
	        }
	        request.getRequestDispatcher("register.jsp").forward(request, response);

	    } catch (Exception e) {
	        e.printStackTrace();
	        request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
	        request.getRequestDispatcher("register.jsp").forward(request, response);
	    }
	}

}
