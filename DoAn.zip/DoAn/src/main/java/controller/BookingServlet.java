package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user"); // Lấy thông tin user từ session

        if (currentUser == null) {
            // Nếu chưa đăng nhập, chuyển hướng đến trang đăng nhập
            response.sendRedirect("login.jsp");
        } else {
            // Lấy thông tin chuyến bay từ request
            String flightNumber = request.getParameter("flightNumber");
            String flightID = request.getParameter("flightID");
            String price = request.getParameter("price");
            String airline = request.getParameter("airline");
            String departureCity = request.getParameter("departureCity");
            String arrivalCity = request.getParameter("arrivalCity");
            String departureTime = request.getParameter("departureTime");
            String arrivalTime = request.getParameter("arrivalTime");

            // Lưu thông tin chuyến bay vào request
            request.setAttribute("flightNumber", flightNumber);
            request.setAttribute("flightID", flightID);
            request.setAttribute("price", price);
            request.setAttribute("airline", airline);
            request.setAttribute("departureCity", departureCity);
            request.setAttribute("arrivalCity", arrivalCity);
            request.setAttribute("departureTime", departureTime);
            request.setAttribute("arrivalTime", arrivalTime);

            // Lưu thông tin người dùng vào request từ session
            request.setAttribute("userFullName", currentUser.getFullName());
            request.setAttribute("userName", currentUser.getUsername());
            request.setAttribute("userPhone", currentUser.getPhone());
            request.setAttribute("userEmail", currentUser.getEmail());
            

            // Chuyển hướng đến trang thanh toán
            request.getRequestDispatcher("payment.jsp").forward(request, response);
        }
    }
}
