package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

@WebServlet("/contactServlet")
public class ContactServlet extends HttpServlet {
	  // Định nghĩa serialVersionUID
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy thông tin từ form
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");

        // Địa chỉ email nhận phản hồi
        String recipient = "22130092@st.hcmuaf.edu.vn";

        // Gửi email
        boolean emailSent = sendEmail(recipient, name, email, subject, message);

        // Phản hồi cho người dùng
        if (emailSent) {
            response.getWriter().println("Cảm ơn bạn đã liên hệ. Chúng tôi sẽ phản hồi sớm nhất có thể!");
        } else {
            response.getWriter().println("Có lỗi xảy ra khi gửi email. Vui lòng thử lại sau.");
        }
    }

    private boolean sendEmail(String recipient, String name, String email, String subject, String messageContent) {
        final String senderEmail = "avcbvc99@gmailcom"; // Email của bạn
        final String senderPassword = "0921432352Aa"; // Mật khẩu ứng dụng của bạn

        // Cấu hình SMTP
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        // Tạo phiên làm việc
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            // Tạo email
            Message message = new MimeMessage(session);

            // Xử lý lỗi UnsupportedEncodingException
            try {
                message.setFrom(new InternetAddress(senderEmail, "Contact Form"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return false;
            }

            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
            message.setSubject("Contact Form: " + subject);
            message.setText("Name: " + name + "\n"
                            + "Email: " + email + "\n"
                            + "Message:\n" + messageContent);

            // Gửi email
            Transport.send(message);
            return true;
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }
}
