//package controller;
//
//import jakarta.servlet.Filter;
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.ServletRequest;
//import jakarta.servlet.ServletResponse;
//import jakarta.servlet.annotation.WebFilter;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpSession;
//
//import java.io.IOException;
//
///**
// * Servlet implementation class AuthenticationFilter
// */
//@WebFilter("/*")
//public class AuthenticationFilter implements Filter {
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//            throws IOException, ServletException {
//        HttpServletRequest req = (HttpServletRequest) request;
//        HttpServletResponse res = (HttpServletResponse) response;
//
//        HttpSession session = req.getSession(false);
//        String uri = req.getRequestURI();
//
//        if (uri.contains("login.jsp") || uri.contains("LoginServlet") || uri.contains("resources")) {
//            chain.doFilter(request, response);
//        } else if (session == null || session.getAttribute("user") == null) {
//            res.sendRedirect("login.jsp");
//        } else {
//            chain.doFilter(request, response);
//        }
//	}
//
//}
