package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.FlightDAO;
import model.Flight;

import java.io.IOException;

@WebServlet("/editFlight")
public class EditFlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve parameters from the form
        int flightId = Integer.parseInt(request.getParameter("flightId"));
        String airline = request.getParameter("airline");
        String flightNumber = request.getParameter("flightNumber");
        String departureCity = request.getParameter("departureCity");
        String arrivalCity = request.getParameter("arrivalCity");
        String departureTime = request.getParameter("departureTime"); // New parameter for departure time
        String arrivalTime = request.getParameter("arrivalTime"); // New parameter for arrival time
        double price = Double.parseDouble(request.getParameter("price"));
        int seatsAvailable = Integer.parseInt(request.getParameter("seatsAvailable"));

        // Print parameters for debugging
        System.out.println("flightId: " + flightId);
        System.out.println("airline: " + airline);
        System.out.println("flightNumber: " + flightNumber);
        System.out.println("departureCity: " + departureCity);
        System.out.println("arrivalCity: " + arrivalCity);
        System.out.println("departureTime: " + departureTime); // Log departure time
        System.out.println("arrivalTime: " + arrivalTime); // Log arrival time
        System.out.println("price: " + price);
        System.out.println("seatsAvailable: " + seatsAvailable);

        // Create a new Flight object and set its values
        Flight flight = new Flight();
        flight.setFlightId(flightId);
        flight.setAirline(airline);
        flight.setFlightNumber(flightNumber);
        flight.setDepartureCity(departureCity);
        flight.setArrivalCity(arrivalCity);
        flight.setDepartureTime(departureTime); // Set departure time
        flight.setArrivalTime(arrivalTime); // Set arrival time
        flight.setPrice(price);
        flight.setSeatsAvailable(seatsAvailable);

        // Update the flight in the database
        int result = FlightDAO.getInstance().update(flight);

        // Handle the result
        if (result > 0) {
            request.getSession().setAttribute("message", "Flight updated successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to update flight.");
        }

        // Redirect back to the admin page
        response.sendRedirect("admin.jsp");
    }
}
