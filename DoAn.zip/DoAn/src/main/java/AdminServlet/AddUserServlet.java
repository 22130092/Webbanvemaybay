package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;
import dao.UserDAO;

import java.io.IOException;

@WebServlet("/addUser")
public class AddUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        int roleId = Integer.parseInt(request.getParameter("role"));

        // Tạo đối tượng User mới
        User user = new User(0, username, password, fullName, email, phone, roleId);

        // Kiểm tra xem tên đăng nhập đã tồn tại chưa
        if (UserDAO.getInstance().isUsernameTaken(username)) {
            request.getSession().setAttribute("message", "Username already exists.");
            response.sendRedirect("admin.jsp"); // Redirect back to admin page with error message
            return;
        }

        // Thêm người dùng vào cơ sở dữ liệu
        int result = UserDAO.getInstance().insert(user);

        // Xử lý kết quả
        if (result > 0) {
            request.getSession().setAttribute("message", "User added successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to add user.");
        }

        // Redirect về trang admin
        response.sendRedirect("admin.jsp");
    }
}
