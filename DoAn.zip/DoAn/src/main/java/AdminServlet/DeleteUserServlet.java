package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.UserDAO;
import model.User;

import java.io.IOException;

@WebServlet("/deleteUser")
public class DeleteUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username and other parameters from the request
        String username = request.getParameter("username");
        
        // Create a new User object (use only the username for deletion)
        User user = new User();
        user.setUsername(username);

        // Call the delete method from UserDAO
        int result = UserDAO.getInstance().delete(user);

        // Check if the deletion was successful
        if (result > 0) {
            request.getSession().setAttribute("message", "User deleted successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to delete user.");
        }

        // Redirect to the admin page
        response.sendRedirect("admin.jsp");
    }
}
