package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.FlightDAO;
import model.Flight;

import java.io.IOException;

@WebServlet("/addFlight")
public class AddFlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve parameters from the form
        String airline = request.getParameter("airline");
        String flightNumber = request.getParameter("flightNumber");
        String departureCity = request.getParameter("departureCity");
        String arrivalCity = request.getParameter("arrivalCity");
        String departureTime = request.getParameter("departureTime"); // New parameter
        String arrivalTime = request.getParameter("arrivalTime"); // New parameter
        double price = Double.parseDouble(request.getParameter("price"));
        int seatsAvailable = Integer.parseInt(request.getParameter("seatsAvailable"));

        // Print out the values of the parameters for debugging
        System.out.println("Airline: " + airline);
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Departure City: " + departureCity);
        System.out.println("Arrival City: " + arrivalCity);
        System.out.println("Departure Time: " + departureTime);
        System.out.println("Arrival Time: " + arrivalTime);
        System.out.println("Price: " + price);
        System.out.println("Seats Available: " + seatsAvailable);

        // Create a new Flight object and set values
        Flight flight = new Flight();
        flight.setAirline(airline);
        flight.setFlightNumber(flightNumber);
        flight.setDepartureCity(departureCity);
        flight.setArrivalCity(arrivalCity);
        flight.setDepartureTime(departureTime); // Set departure time
        flight.setArrivalTime(arrivalTime); // Set arrival time
        flight.setPrice(price);
        flight.setSeatsAvailable(seatsAvailable);

        // Add the flight to the database
        int result = FlightDAO.getInstance().insert(flight);

        // Handle the result
        if (result > 0) {
            request.getSession().setAttribute("message", "Flight added successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to add flight.");
        }

        // Redirect back to the admin page
        response.sendRedirect("admin.jsp");
    }
}
