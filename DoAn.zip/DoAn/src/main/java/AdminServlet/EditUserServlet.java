package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.UserDAO;
import model.User;

import java.io.IOException;

@WebServlet("/editUser")
public class EditUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy các tham số từ form
        int userId = Integer.parseInt(request.getParameter("userId"));
        String username = request.getParameter("username");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        int roleId = Integer.parseInt(request.getParameter("role"));

        // In ra các tham số nhận được để kiểm tra
        System.out.println("userId: " + userId);
        System.out.println("username: " + username);
        System.out.println("fullName: " + fullName);
        System.out.println("email: " + email);
        System.out.println("phone: " + phone);
        System.out.println("roleId: " + roleId);

        // Tạo đối tượng User
        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setRoleId(roleId);

        // Gọi phương thức update từ UserDAO để cập nhật thông tin người dùng
        int result = UserDAO.getInstance().update(user);

        // Kiểm tra kết quả cập nhật
        if (result > 0) {
            request.getSession().setAttribute("message", "User updated successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to update user.");
        }

        // Chuyển hướng về trang quản lý admin
        response.sendRedirect("admin.jsp");
    }
}
