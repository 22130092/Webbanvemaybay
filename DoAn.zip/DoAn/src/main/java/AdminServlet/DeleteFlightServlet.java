package AdminServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Flight;
import model.User;
import dao.FlightDAO;

import java.io.IOException;

@WebServlet("/deleteFlight")
public class DeleteFlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the flightId to delete
        int flightId = Integer.parseInt(request.getParameter("flightId"));
        Flight f = new Flight();
        
        // Delete the flight from the database
        f.setFlightId(flightId);
        int result = FlightDAO.getInstance().delete(f);

        // Handle the result
        if (result > 0) {
            request.getSession().setAttribute("message", "Flight deleted successfully.");
        } else {
            request.getSession().setAttribute("message", "Failed to delete flight.");
        }

        // Redirect back to the admin page
        response.sendRedirect("admin.jsp");
    }
}
