package model;

import java.util.Date;

public class Booking {
    private int bookingId;
    private int userId;
    private int flightId;
    private int numberOfSeats;
    private double totalPrice;
    private String bookingStatus;
    private Date bookingDate;  // Added BookingDate field

    // Constructor
    
    public Booking(int userId, int flightId, int numberOfSeats, double totalPrice, String bookingStatus) {
        this.userId = userId;
        this.flightId = flightId;
        this.numberOfSeats = numberOfSeats;
        this.totalPrice = totalPrice;
        this.bookingStatus = bookingStatus;
        this.bookingDate = new Date();  // Set the current date when the booking is created
    }

    public Booking() {
		super();
	}

	// Getters and setters for all fields
    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getFlightId() {
        return flightId;
    }

    public void setFlightId(int flightId) {
        this.flightId = flightId;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId + ", flightId=" + flightId + ", numberOfSeats="
				+ numberOfSeats + ", totalPrice=" + totalPrice + ", bookingStatus=" + bookingStatus + ", bookingDate="
				+ bookingDate + "]";
	}
    
}
