package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Role;

public class RoleDAO implements DAOInterface<Role> {
    // Singleton pattern
    public static RoleDAO getInstance() {
        return new RoleDAO();
    }

    @Override
    public int insert(Role role) {
        int kq = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "INSERT INTO Roles (RoleName, Description) VALUES (?, ?)";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, role.getRoleName());
            pr.setString(2, role.getDescription());

            kq += pr.executeUpdate();
            if (kq > 0) {
                System.out.println("Insert " + kq + " dòng thành công");
            } else {
                System.out.println("Insert thất bại");
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int delete(Role role) {
        int kq = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "DELETE FROM Roles WHERE RoleID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, role.getRoleId());

            kq += pr.executeUpdate();
            if (kq > 0) {
                System.out.println("Delete " + kq + " dòng thành công");
            } else {
                System.out.println("Delete thất bại");
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public int update(Role role) {
        int kq = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "UPDATE Roles SET RoleName = ?, Description = ? WHERE RoleID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, role.getRoleName());
            pr.setString(2, role.getDescription());
            pr.setInt(3, role.getRoleId());

            kq += pr.executeUpdate();
            if (kq > 0) {
                System.out.println("Update " + kq + " dòng thành công");
            } else {
                System.out.println("Update thất bại");
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    public ArrayList<Role> selectAll() {
        ArrayList<Role> roles = new ArrayList<>();
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Roles";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Role role = new Role(
                    rs.getInt("RoleID"),
                    rs.getString("RoleName"),
                    rs.getString("Description")
                );
                roles.add(role);
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return roles;
    }

    @Override
    public Role selectById(Role role) {
        Role result = null;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Roles WHERE RoleID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, role.getRoleId());
            ResultSet rs = pr.executeQuery();

            if (rs.next()) {
                result = new Role(
                    rs.getInt("RoleID"),
                    rs.getString("RoleName"),
                    rs.getString("Description")
                );
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public ArrayList<Role> selectByCondition(String condition) {
        ArrayList<Role> roles = new ArrayList<>();
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Roles WHERE " + condition;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Role role = new Role(
                    rs.getInt("RoleID"),
                    rs.getString("RoleName"),
                    rs.getString("Description")
                );
                roles.add(role);
            }

            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return roles;
    }
}
