package dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {
	public static Connection getConnection() {
		Connection c = null;
	
		try {
			//Dang ky mysql dirver voi DriverManager
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			
			//cac thong so
			String url = "jdbc:mySQL://localhost:3306/flight_booking?useUnicode=true&characterEncoding=UTF-8";
			String username ="root";
			String password ="";
			
			// tao ket noi
			c= DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
	}
	public static void closeConnection(Connection c) {
		try {
			if (c!=null) {
				c.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void printInfo(Connection c) {
		try {
			DatabaseMetaData mtdt = c.getMetaData();
			if (c!=null) System.out.println(mtdt.getDatabaseProductName());
			if (c!=null) System.out.println(mtdt.getDatabaseMinorVersion());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
