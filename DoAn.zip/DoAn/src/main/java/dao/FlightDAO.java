package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Flight;

public class FlightDAO implements DAOInterface<Flight> {
	// Singleton pattern
	public static FlightDAO getInstance() {
		return new FlightDAO();
	}

	@Override
	public int insert(Flight flight) {
		int kq = 0;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "INSERT INTO Flights (Airline, FlightNumber, DepartureCity, ArrivalCity, DepartureTime, ArrivalTime, Price, SeatsAvailable) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setString(1, flight.getAirline());
			pr.setString(2, flight.getFlightNumber());
			pr.setString(3, flight.getDepartureCity());
			pr.setString(4, flight.getArrivalCity());
			pr.setString(5, flight.getDepartureTime());
			pr.setString(6, flight.getArrivalTime());
			pr.setDouble(7, flight.getPrice());
			pr.setInt(8, flight.getSeatsAvailable());

			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Insert " + kq + " dòng thành công");
			} else {
				System.out.println("Insert thất bại");
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int delete(Flight flight) {
		int kq = 0;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "DELETE FROM Flights WHERE FlightID = ?";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setInt(1, flight.getFlightId());

			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Delete " + kq + " dòng thành công");
			} else {
				System.out.println("Delete thất bại");
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int update(Flight flight) {
		int kq = 0;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "UPDATE Flights SET Airline = ?, FlightNumber = ?, DepartureCity = ?, ArrivalCity = ?, DepartureTime = ?, ArrivalTime = ?, Price = ?, SeatsAvailable = ? WHERE FlightID = ?";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setString(1, flight.getAirline());
			pr.setString(2, flight.getFlightNumber());
			pr.setString(3, flight.getDepartureCity());
			pr.setString(4, flight.getArrivalCity());
			pr.setString(5, flight.getDepartureTime());
			pr.setString(6, flight.getArrivalTime());
			pr.setDouble(7, flight.getPrice());
			pr.setInt(8, flight.getSeatsAvailable());
			pr.setInt(9, flight.getFlightId());

			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Update " + kq + " dòng thành công");
			} else {
				System.out.println("Update thất bại");
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public ArrayList<Flight> selectAll() {
		ArrayList<Flight> flights = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT * FROM Flights";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Flight flight = new Flight(rs.getInt("FlightID"), rs.getString("Airline"), rs.getString("FlightNumber"),
						rs.getString("DepartureCity"), rs.getString("ArrivalCity"), rs.getString("DepartureTime"),
						rs.getString("ArrivalTime"), rs.getDouble("Price"), rs.getInt("SeatsAvailable"));
				flights.add(flight);
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flights;
	}

	@Override
	public Flight selectById(Flight flight) {
		Flight result = null;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT * FROM Flights WHERE FlightID = ?";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setInt(1, flight.getFlightId());
			ResultSet rs = pr.executeQuery();

			if (rs.next()) {
				result = new Flight(rs.getInt("FlightID"), rs.getString("Airline"), rs.getString("FlightNumber"),
						rs.getString("DepartureCity"), rs.getString("ArrivalCity"), rs.getString("DepartureTime"),
						rs.getString("ArrivalTime"), rs.getDouble("Price"), rs.getInt("SeatsAvailable"));
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public ArrayList<Flight> selectByCondition(String condition) {
		ArrayList<Flight> flights = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT * FROM Flights WHERE " + condition;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Flight flight = new Flight(rs.getInt("FlightID"), rs.getString("Airline"), rs.getString("FlightNumber"),
						rs.getString("DepartureCity"), rs.getString("ArrivalCity"), rs.getString("DepartureTime"),
						rs.getString("ArrivalTime"), rs.getDouble("Price"), rs.getInt("SeatsAvailable"));
				flights.add(flight);
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flights;
	}

	public ArrayList<String> getDistinctDepartureCities() {
		ArrayList<String> cities = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT DISTINCT DepartureCity FROM Flights";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				cities.add(rs.getString("DepartureCity"));
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cities;
	}

	public ArrayList<String> getDistinctArrivalCities() {
		ArrayList<String> cities = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT DISTINCT ArrivalCity FROM Flights";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				cities.add(rs.getString("ArrivalCity"));
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cities;
	}

	public ArrayList<String> getDistinctAirlines() {
		ArrayList<String> airlines = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT DISTINCT Airline FROM Flights";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				airlines.add(rs.getString("Airline"));
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return airlines;
	}
	public ArrayList<Flight> getPromotionalFlights(String city) {
	    ArrayList<Flight> flights = new ArrayList<>();
	    try {
	        Connection con = ConnectDB.getConnection();
	        // Query that checks both DepartureCity and ArrivalCity
	        String sql = "SELECT * FROM Flights";
	        PreparedStatement pr = con.prepareStatement(sql);

	        ResultSet rs = pr.executeQuery();

	        while (rs.next()) {
	            Flight flight = new Flight(
	                rs.getInt("FlightID"),
	                rs.getString("Airline"),
	                rs.getString("FlightNumber"),
	                rs.getString("DepartureCity"),
	                rs.getString("ArrivalCity"),
	                rs.getString("DepartureTime"),
	                rs.getString("ArrivalTime"),
	                rs.getDouble("Price"),
	                rs.getInt("SeatsAvailable")
	            );
	            flights.add(flight);
	        }
	        ConnectDB.closeConnection(con);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return flights;
	}

	public ArrayList<Flight> searchFlights(String fromCity, String toCity, String departureDate) {
	    ArrayList<Flight> flights = new ArrayList<>();
	    String sql = "SELECT * FROM Flights WHERE DepartureCity = ? AND ArrivalCity = ?";
	    
	    // Nếu có departureDate, thêm điều kiện vào truy vấn
	    if (departureDate != null && !departureDate.isEmpty()) {
	        sql += " AND DepartureTime LIKE ?";
	    }

	    try (Connection con = ConnectDB.getConnection();
	         PreparedStatement pr = con.prepareStatement(sql)) {

	        // Gán giá trị cho các tham số
	        pr.setString(1, fromCity);
	        pr.setString(2, toCity);
	        if (departureDate != null && !departureDate.isEmpty()) {
	            pr.setString(3, departureDate + "%");
	        }

	        ResultSet rs = pr.executeQuery();
	        while (rs.next()) {
	            Flight flight = new Flight(
	                rs.getInt("FlightID"),
	                rs.getString("Airline"),
	                rs.getString("FlightNumber"),
	                rs.getString("DepartureCity"),
	                rs.getString("ArrivalCity"),
	                rs.getString("DepartureTime"),
	                rs.getString("ArrivalTime"),
	                rs.getDouble("Price"),
	                rs.getInt("SeatsAvailable")
	            );
	            flights.add(flight);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return flights;
	}
	public static ArrayList<String> getDistinctDepartureCitiesDirect() {
	    ArrayList<String> cities = new ArrayList<>();
	    try {
	        Connection con = ConnectDB.getConnection();
	        String sql = "SELECT DISTINCT DepartureCity FROM Flights";
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(sql);

	        while (rs.next()) {
	            cities.add(rs.getString("DepartureCity"));
	        }

	        ConnectDB.closeConnection(con);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return cities;
	}




}
