package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

import model.Booking;

public class BookingDAO implements DAOInterface<Booking> {
    // Singleton pattern
    public static BookingDAO getInstance() {
        return new BookingDAO();
    }

    @Override
    public int insert(Booking booking) {
        int result = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "INSERT INTO Bookings (UserID, FlightID, NumberOfSeats, TotalPrice, BookingStatus, BookingDate) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, booking.getUserId());
            pr.setInt(2, booking.getFlightId());
            pr.setInt(3, booking.getNumberOfSeats());
            pr.setDouble(4, booking.getTotalPrice());
            pr.setString(5, booking.getBookingStatus());
            pr.setTimestamp(6, new java.sql.Timestamp(booking.getBookingDate().getTime()));  // Set booking date

            result = pr.executeUpdate();
            if (result > 0) {
                System.out.println("Inserted " + result + " row(s) successfully.");
            } else {
                System.out.println("Insert failed.");
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }


    @Override
    public int delete(Booking booking) {
        int result = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "DELETE FROM Bookings WHERE BookingID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, booking.getBookingId());

            result = pr.executeUpdate();
            if (result > 0) {
                System.out.println("Deleted " + result + " row(s) successfully.");
            } else {
                System.out.println("Delete failed.");
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public int update(Booking booking) {
        int result = 0;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "UPDATE Bookings SET UserID = ?, FlightID = ?, NumberOfSeats = ?, TotalPrice = ?, BookingStatus = ? WHERE BookingID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, booking.getUserId());
            pr.setInt(2, booking.getFlightId());
            pr.setInt(3, booking.getNumberOfSeats());
            pr.setDouble(4, booking.getTotalPrice());
            pr.setString(5, booking.getBookingStatus());
            pr.setInt(6, booking.getBookingId());

            result = pr.executeUpdate();
            if (result > 0) {
                System.out.println("Updated " + result + " row(s) successfully.");
            } else {
                System.out.println("Update failed.");
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public ArrayList<Booking> selectAll() {
        ArrayList<Booking> bookings = new ArrayList<>();
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Bookings";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Booking result = new Booking();

                // Set the values using setters
                result.setBookingId(rs.getInt("BookingID"));
                result.setUserId(rs.getInt("UserID"));
                result.setFlightId(rs.getInt("FlightID"));
                result.setNumberOfSeats(rs.getInt("NumberOfSeats"));
                result.setTotalPrice(rs.getDouble("TotalPrice"));
                result.setBookingStatus(rs.getString("BookingStatus"));
                result.setBookingDate(rs.getTimestamp("BookingDate")); 
                bookings.add(result);
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }

    @Override
    public Booking selectById(Booking booking) {
        Booking result = null;
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Bookings WHERE BookingID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, booking.getBookingId());
            ResultSet rs = pr.executeQuery();

            if (rs.next()) {
            	 result = new Booking();

                 // Set the values using setters
                 result.setBookingId(rs.getInt("BookingID"));
                 result.setUserId(rs.getInt("UserID"));
                 result.setFlightId(rs.getInt("FlightID"));
                 result.setNumberOfSeats(rs.getInt("NumberOfSeats"));
                 result.setTotalPrice(rs.getDouble("TotalPrice"));
                 result.setBookingStatus(rs.getString("BookingStatus"));
                 result.setBookingDate(rs.getTimestamp("BookingDate")); 
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public ArrayList<Booking> selectByCondition(String condition) {
        ArrayList<Booking> bookings = new ArrayList<>();
        try {
            Connection con = ConnectDB.getConnection();
            String sql = "SELECT * FROM Bookings WHERE " + condition;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Booking  result = new Booking();

                // Set the values using setters
                result.setBookingId(rs.getInt("BookingID"));
                result.setUserId(rs.getInt("UserID"));
                result.setFlightId(rs.getInt("FlightID"));
                result.setNumberOfSeats(rs.getInt("NumberOfSeats"));
                result.setTotalPrice(rs.getDouble("TotalPrice"));
                result.setBookingStatus(rs.getString("BookingStatus"));
                result.setBookingDate(rs.getTimestamp("BookingDate")); 
                bookings.add(result);
            }
            ConnectDB.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }
    public static void main(String[] args) {
        // Create a new Booking object
        Booking booking = new Booking();
        
        // Set values for the booking object
        booking.setUserId(25);  // Example UserID
        booking.setFlightId(105);  // Example FlightID
        booking.setNumberOfSeats(2);  // Example number of seats
        booking.setTotalPrice(200.50);  // Example total price
        booking.setBookingStatus("Confirmed");  // Example booking status
        booking.setBookingDate(new Date());  // Current date as booking date

        // Insert the booking into the database using BookingDAO
        BookingDAO bookingDAO = BookingDAO.getInstance();
        int result = bookingDAO.insert(booking);
        
        // Output result to verify the insert operation
        if (result > 0) {
            System.out.println("Booking inserted successfully!");
        } else {
            System.out.println("Booking insertion failed.");
        }
    }
}
