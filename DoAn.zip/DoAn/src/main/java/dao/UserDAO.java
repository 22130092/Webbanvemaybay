package dao;

import java.sql.*;
import java.util.ArrayList;
import org.mindrot.jbcrypt.BCrypt;

import model.User;

public class UserDAO implements DAOInterface<User> {
	// Singleton pattern
	public static UserDAO getInstance() {
		return new UserDAO();
	}

	@Override
	public int insert(User user) {
		int kq = 0;
		try {
			// B1: Tạo kết nối đến CSDL
			Connection con = ConnectDB.getConnection();
			String sql = "INSERT INTO Users (Username, PasswordHash, FullName, Email, Phone, RoleID) VALUES (?, ?, ?, ?, ?, ?)";

			// B2: Tạo đối tượng statement
			PreparedStatement pr = con.prepareStatement(sql);
			String hashedPassword = BCrypt.hashpw(user.getPasswordHash(), BCrypt.gensalt());
			// B3: Thực thi câu lệnh SQL
			pr.setString(1, user.getUsername());
			pr.setString(2, hashedPassword);
			pr.setString(3, user.getFullName());
			pr.setString(4, user.getEmail());
			pr.setString(5, user.getPhone());
			pr.setInt(6, user.getRoleId());

			// B4: Xử lý kết quả trả về
			System.out.println("Bạn đã thực thi: " + sql);
			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Insert " + kq + " dòng thành công");
			} else {
				System.out.println("Insert thất bại");
			}

			// B5: Đóng kết nối
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int delete(User user) {
		int kq = 0;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "DELETE FROM Users WHERE username = ?";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setString(1, user.getUsername());

			System.out.println("Bạn đã thực thi: " + sql);
			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Delete " + kq + " dòng thành công");
			} else {
				System.out.println("Delete thất bại");
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public int update(User user) {
		int kq = 0;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "UPDATE Users SET Username = ?, FullName = ?, Email = ?, Phone = ?, RoleID = ? WHERE UserID = ?";
			PreparedStatement pr = con.prepareStatement(sql);
			pr.setString(1, user.getUsername());
			pr.setString(2, user.getFullName());
			pr.setString(3, user.getEmail());
			pr.setString(4, user.getPhone());
			pr.setInt(5, user.getRoleId());
			pr.setInt(6, user.getUserId());

			System.out.println("Bạn đã thực thi: " + sql);
			kq += pr.executeUpdate();
			if (kq > 0) {
				System.out.println("Update " + kq + " dòng thành công");
			} else {
				System.out.println("Update thất bại");
			}

			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return kq;
	}

	@Override
	public ArrayList<User> selectAll() {
		ArrayList<User> users = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT * FROM Users";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				User user = new User(rs.getInt("UserID"), rs.getString("Username"), rs.getString("PasswordHash"),
						rs.getString("FullName"), rs.getString("Email"), rs.getString("Phone"), rs.getInt("RoleID"));
				users.add(user);
			}

			System.out.println("Bạn đã thực thi: " + sql);
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public User selectById(User user) {
		if (user == null || user.getUsername() == null) {
			System.out.println("User or username is null.");
			return null;
		}

		User result = null;
		String sql = "SELECT * FROM Users WHERE Username = ?";

		try (Connection con = ConnectDB.getConnection(); PreparedStatement pr = con.prepareStatement(sql)) {

			pr.setString(1, user.getUsername());

			try (ResultSet rs = pr.executeQuery()) {
				if (rs.next()) {
					result = new User(rs.getInt("UserID"), rs.getString("Username"), rs.getString("PasswordHash"),
							rs.getString("FullName"), rs.getString("Email"), rs.getString("Phone"),
							rs.getInt("RoleID"));
				}
			}

			System.out.println("Query executed: " + sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Database error: " + e.getMessage());
		}

		return result;
	}

	@Override
	public ArrayList<User> selectByCondition(String condition) {
		ArrayList<User> users = new ArrayList<>();
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT * FROM Users WHERE " + condition;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				User user = new User(rs.getInt("UserID"), rs.getString("Username"), rs.getString("PasswordHash"),
						rs.getString("FullName"), rs.getString("Email"), rs.getString("Phone"), rs.getInt("RoleID"));
				users.add(user);
			}

			System.out.println("Bạn đã thực thi: " + sql);
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	public User login(String username, String password) {
		User user = null;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT u.*, r.RoleName FROM users u INNER JOIN roles r ON u.RoleID = r.RoleID WHERE u.Username = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String hashedPassword = rs.getString("PasswordHash");
				if (BCrypt.checkpw(password, hashedPassword)) {
					user = new User();
					user.setFullName(rs.getString("FullName"));
					user.setUserId(rs.getInt("UserID"));
					user.setUsername(rs.getString("FullName"));
					user.setEmail(rs.getString("Email"));
					user.setPhone(rs.getString("Phone"));
					user.setRoleId(rs.getInt("RoleID"));
					System.out.println(user);
				}
			}
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	public boolean isUsernameTaken(String username) {
		boolean isTaken = false;
		try {
			Connection con = ConnectDB.getConnection();
			String sql = "SELECT COUNT(*) FROM Users WHERE Username = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				isTaken = rs.getInt(1) > 0;
			}
			ConnectDB.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isTaken;
	}

	public User getUserByUsername(String username) {
		if (username == null || username.isEmpty()) {
			System.out.println("Username is null or empty.");
			return null;
		}

		User result = null;
		String sql = "SELECT * FROM Users WHERE Username = ?";

		try (Connection con = ConnectDB.getConnection(); PreparedStatement pr = con.prepareStatement(sql)) {

			pr.setString(1, username);

			try (ResultSet rs = pr.executeQuery()) {
				if (rs.next()) {
					result = new User(rs.getInt("UserID"), rs.getString("Username"), rs.getString("PasswordHash"),
							rs.getString("FullName"), rs.getString("Email"), rs.getString("Phone"),
							rs.getInt("RoleID"));
				}
			}

			System.out.println("Query executed: " + sql);

		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Database error: " + e.getMessage());
		}

		return result;
	}
}
